(function () {
  function readJSON(id) {
    var el = document.getElementById(id);
    if (!el) return null;
    try { return JSON.parse(el.textContent); } catch (e) { return null; }
  }

  function makeChart(canvasId, config) {
    var canvas = document.getElementById(canvasId);
    if (!canvas || typeof Chart === 'undefined') return;
    new Chart(canvas.getContext('2d'), config);
  }

  document.addEventListener('DOMContentLoaded', function () {
    var teamPoints = readJSON('chart-data-team-points');
    if (teamPoints) {
      makeChart('teamPointsChart', {
        type: 'bar',
        data: {
          labels: teamPoints.labels,
          datasets: [{ label: 'Points', data: teamPoints.values, backgroundColor: '#16a34a' }],
        },
        options: { responsive: true, plugins: { legend: { display: false } } },
      });
    }

    var topScorers = readJSON('chart-data-top-scorers');
    if (topScorers) {
      makeChart('topScorersChart', {
        type: 'bar',
        data: {
          labels: topScorers.labels,
          datasets: [{ label: 'Runs', data: topScorers.values, backgroundColor: '#0a1930' }],
        },
        options: { responsive: true, indexAxis: 'y', plugins: { legend: { display: false } } },
      });
    }

    var topWickets = readJSON('chart-data-top-wickets');
    if (topWickets) {
      makeChart('topWicketsChart', {
        type: 'bar',
        data: {
          labels: topWickets.labels,
          datasets: [{ label: 'Wickets', data: topWickets.values, backgroundColor: '#d4a017' }],
        },
        options: { responsive: true, indexAxis: 'y', plugins: { legend: { display: false } } },
      });
    }

    var winsLosses = readJSON('chart-data-wins-losses');
    if (winsLosses) {
      makeChart('winsLossesChart', {
        type: 'bar',
        data: {
          labels: winsLosses.labels,
          datasets: [
            { label: 'Wins', data: winsLosses.wins, backgroundColor: '#16a34a' },
            { label: 'Losses', data: winsLosses.losses, backgroundColor: '#dc2626' },
          ],
        },
        options: { responsive: true, scales: { x: { stacked: true }, y: { stacked: true } } },
      });
    }

    var strikeRates = readJSON('chart-data-strike-rates');
    if (strikeRates) {
      makeChart('strikeRatesChart', {
        type: 'line',
        data: {
          labels: strikeRates.labels,
          datasets: [{ label: 'Strike Rate', data: strikeRates.values, borderColor: '#16a34a', tension: 0.3 }],
        },
        options: { responsive: true },
      });
    }
  });
})();
