document.addEventListener('DOMContentLoaded', function () {
  var messagesEl = document.getElementById('chatMessages');
  var formEl = document.getElementById('chatForm');
  var inputEl = document.getElementById('chatInput');
  var sendBtn = formEl ? formEl.querySelector('button[type="submit"]') : null;
  var personaEl = document.getElementById('personaSelect');
  var levelEl = document.getElementById('levelSelect');
  var clearBtn = document.getElementById('clearChatBtn');
  var suggestedEl = document.getElementById('suggestedQuestions');

  if (!messagesEl || !formEl) {
    console.error('IPL AI Hub chat: required DOM elements not found; chat cannot start.');
    return;
  }

  var STORAGE_KEY = 'ipl_ai_hub_session_key';
  var sessionKey = null;
  try { sessionKey = window.localStorage ? window.localStorage.getItem(STORAGE_KEY) : null; } catch (e) { sessionKey = null; }

  function addMessage(role, text) {
    var wrap = document.createElement('div');
    wrap.className = 'chat-message ' + role;
    wrap.textContent = text;
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return wrap;
  }

  function addTyping() {
    removeTyping();
    var el = document.createElement('div');
    el.className = 'typing-indicator';
    el.id = 'typingIndicator';
    el.textContent = 'AI Cricket Assistant is typing...';
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function removeTyping() {
    var el = document.getElementById('typingIndicator');
    if (el) el.remove();
  }

  function showWelcome() {
    messagesEl.innerHTML = '';
    addMessage('ai', (window.IPL_AI_WELCOME || "👋 Welcome to IPL AI Hub!\n\nI'm your AI Cricket Assistant.\nWhat would you like to explore today?"));
  }

  function setBusy(busy) {
    if (inputEl) inputEl.disabled = busy;
    if (sendBtn) sendBtn.disabled = busy;
  }

  function getCookie(name) {
    if (window.iplAiHub && typeof window.iplAiHub.getCookie === 'function') {
      return window.iplAiHub.getCookie(name);
    }
    var value = '; ' + document.cookie;
    var parts = value.split('; ' + name + '=');
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
  }

  function sendQuestion(question) {
    question = (question || '').trim();
    if (!question) return;

    addMessage('user', question);
    addTyping();
    setBusy(true);

    fetch('/api/ai/ask/', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCookie('csrftoken') || '',
      },
      body: JSON.stringify({
        question: question,
        persona: personaEl ? personaEl.value : 'CASUAL_FAN',
        level: levelEl ? levelEl.value : 'BEGINNER',
        session_key: sessionKey || '',
      }),
    })
      .then(function (resp) {
        var contentType = resp.headers.get('content-type') || '';
        if (contentType.indexOf('application/json') === -1) {
          // The server returned something that isn't JSON -- most likely a
          // Django error page (e.g. a 500 with DEBUG on, or a 404 because
          // the app isn't wired up as expected). Surface that clearly
          // instead of silently failing.
          return resp.text().then(function (text) {
            throw new Error(
              'Server returned ' + resp.status + ' ' + resp.statusText +
              ' (expected JSON). Check the terminal running `py manage.py runserver` ' +
              'for the actual error. First 200 chars of response: ' +
              text.slice(0, 200)
            );
          });
        }
        return resp.json().then(function (data) { return { ok: resp.ok, status: resp.status, data: data }; });
      })
      .then(function (result) {
        removeTyping();
        if (!result.ok) {
          var detail = (result.data && (result.data.detail || JSON.stringify(result.data.errors))) || ('HTTP ' + result.status);
          addMessage('error', 'The assistant could not process that (' + detail + '). Try rephrasing your question.');
          console.error('IPL AI Hub chat: API returned an error response', result);
          return;
        }
        if (result.data.success === false) {
          addMessage('error', result.data.answer || 'Something went wrong answering that question.');
          return;
        }
        if (result.data.session_key) {
          sessionKey = result.data.session_key;
          try { window.localStorage && window.localStorage.setItem(STORAGE_KEY, sessionKey); } catch (e) { /* ignore */ }
        }
        addMessage('ai', result.data.answer);
      })
      .catch(function (err) {
        removeTyping();
        console.error('IPL AI Hub chat: request failed', err);
        addMessage(
          'error',
          'Could not reach the AI assistant (' + err.message + '). ' +
          'Make sure `py manage.py runserver` is running and you opened the site at 127.0.0.1:8000.'
        );
      })
      .finally(function () {
        setBusy(false);
        if (inputEl) inputEl.focus();
      });
  }

  formEl.addEventListener('submit', function (e) {
    e.preventDefault();
    var question = inputEl.value.trim();
    if (!question) return;
    inputEl.value = '';
    sendQuestion(question);
  });

  if (suggestedEl) {
    suggestedEl.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-question]');
      if (btn) sendQuestion(btn.getAttribute('data-question'));
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      showWelcome();
    });
  }

  showWelcome();
});
