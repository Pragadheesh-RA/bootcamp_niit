# IPL AI Hub

A production-style Django web application for IPL cricket analytics, featuring
a full Teams/Players/Matches/Points-Table/Statistics/Articles platform and a
built-in **AI Cricket Assistant** chatbot — all running on Django, Django REST
Framework, and SQLite, with zero external services required.

## 1. Project Overview

IPL AI Hub is an intelligent cricket analytics and information platform. It
combines a relational data model for teams, players, matches, and content
with a rule-based AI service that answers natural-language cricket questions
by querying the same database the rest of the site uses. The AI service is
fully local (no API key needed) but is architected so an external LLM can be
plugged in later without changing its public interface.

## 2. Features

- **Dashboard** with headline stats: teams, players, matches, top performers, points leader.
- **Teams module**: profiles, search, filtering, squad, match history, team stats.
- **Players module**: profiles, search, team/role filtering, sorting by runs/wickets/strike rate.
- **Matches module**: upcoming/recent matches, filtering by team/date/status, match detail pages.
- **Points table**: full standings sorted by points then Net Run Rate, with a playoff-qualification highlight.
- **Statistics module**: batting/bowling leaderboards and Chart.js visualizations.
- **Articles/content module**: categorized cricket content with tags, search, and related articles.
- **Global search** across teams, players, matches, and articles.
- **AI Cricket Assistant**: a chat interface with intent detection, persona selection (Casual Fan,
  Beginner, Student, Cricket Analyst, Data Analyst, Coach, Researcher), and explanation levels
  (Beginner/Intermediate/Advanced/Expert). The endpoint is defensive by design — it always returns
  JSON, even if something goes wrong internally, so the chat widget never fails silently.
- **REST API** covering every module, browsable via DRF.
- **Django Admin** configured for managing all data.
- **Pytest suite** covering models, APIs, AI intents, and frontend views.
- **Data seeding command** for realistic demo data — usable immediately after migration.

## 3. Technology Stack

- Django 4.2 (LTS)
- Django REST Framework
- SQLite (default database — no server required)
- HTML5, CSS3, vanilla JavaScript (no frontend build step)
- Chart.js (loaded from CDN) for statistics visualizations
- Pytest + pytest-django for testing

## 4. Project Structure

```
ipl_ai_hub/
├── manage.py
├── requirements.txt
├── pytest.ini
├── .env.example
├── .gitignore
├── README.md
│
├── config/                  # Django project (settings, root urls, wsgi/asgi)
├── core/                     # The "core" application
│   ├── admin.py
│   ├── models.py
│   ├── serializers.py
│   ├── urls.py               # Frontend page routes
│   ├── api_urls.py           # REST API routes (mounted at /api/)
│   ├── views.py               # Template-rendering views
│   ├── api_views.py           # DRF API views/viewsets (incl. AIAskAPIView)
│   ├── services/
│   │   ├── ai.py              # AI Cricket Assistant (intent detection + responses)
│   │   ├── statistics.py      # Aggregate/statistics queries
│   │   └── search.py          # Global search
│   ├── management/commands/seed_data.py
│   ├── migrations/
│   └── tests/
│
├── templates/                 # Django templates (base + per-module pages)
├── static/{css,js,images}/    # Stylesheets, JavaScript, images
└── media/                     # User-uploaded images
```

## 5. Installation (No Virtual Environment Required)

This project runs directly against your system Python installation — no
`venv`, no `.venv\Scripts\activate`.

### Windows PowerShell

```powershell
cd ipl_ai_hub
py --version
py -m pip install -r requirements.txt
copy .env.example .env
py manage.py makemigrations
py manage.py migrate
py manage.py seed_data
py -m pytest
py manage.py createsuperuser
py manage.py runserver
```

### macOS / Linux

```bash
cd ipl_ai_hub
python3 --version
python3 -m pip install -r requirements.txt
cp .env.example .env
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py seed_data
python3 -m pytest
python3 manage.py createsuperuser
python3 manage.py runserver
```

Then open http://127.0.0.1:8000/ (admin at http://127.0.0.1:8000/admin/).

## 6. Dependency Installation

```
Django>=4.2,<5.0
djangorestframework>=3.14,<3.16
python-dotenv>=1.0,<2.0
Pillow>=10.0,<11.0
pytest>=7.4,<8.0
pytest-django>=4.5,<5.0
```

## 7. Environment Setup

Copy `.env.example` to `.env`. `AI_API_KEY` can stay blank — the AI Cricket
Assistant is entirely local and rule-based.

## 8. Database Migration

```powershell
py manage.py makemigrations
py manage.py migrate
```

## 9. Demo Data

```powershell
py manage.py seed_data
```

Add `--flush` to wipe and reload.

## 10. Running the Server

```powershell
py manage.py runserver
```

## 11. Running Tests

```powershell
py -m pytest
```

Covers models, every REST endpoint, AI intent detection (including a test
that every intent handler degrades gracefully on an empty database instead
of raising), and every major frontend page.

## 12. Admin Setup

```powershell
py manage.py createsuperuser
```

## 13. API Documentation

| Endpoint | Methods | Description |
|---|---|---|
| `/api/teams/` | GET, POST | List/create teams |
| `/api/teams/<id>/` | GET, PUT, PATCH, DELETE | Retrieve/update/delete a team |
| `/api/players/` | GET, POST | List/create players (`?team=`, `?role=`) |
| `/api/players/<id>/` | GET, PUT, PATCH, DELETE | Retrieve/update/delete a player |
| `/api/matches/` | GET, POST | List/create matches (`?status=`, `?team=`, `?date=`) |
| `/api/matches/<id>/` | GET, PUT, PATCH, DELETE | Retrieve/update/delete a match |
| `/api/standings/` | GET | Points table |
| `/api/statistics/` | GET | Batting/bowling leaderboards |
| `/api/articles/` | GET, POST | List/create articles (`?category=`, `?tag=`) |
| `/api/articles/<slug>/` | GET, PUT, PATCH, DELETE | Retrieve/update/delete an article |
| `/api/search/` | GET | Global search (`?q=`) |
| `/api/ai/ask/` | POST | AI Cricket Assistant |
| `/api/ai/welcome/` | GET | Welcome message + suggested questions |

### AI API example

```json
POST /api/ai/ask/
{ "question": "Who has scored the most runs?", "persona": "Casual Fan", "level": "Beginner" }
```

```json
{
  "success": true,
  "intent": "TOP_RUNS",
  "answer": "Hey there! Virat Kohli (RCB) leads with 460 runs this season.",
  "data": { "top_scorers": [ { "name": "Virat Kohli", "team": "RCB", "runs": 460 } ] },
  "source": "database",
  "session_key": "..."
}
```

The endpoint always returns JSON with a `success` flag, even on internal
errors — it does not require authentication or a CSRF token to call, since
it's read/write against anonymous chat sessions, not user accounts.

## 14. AI Architecture

```
Frontend  ->  Django API (AIAskAPIView)  ->  AI Service (core/services/ai.py)
                                                 -> Intent Detection
                                                 -> Database Query (statistics.py, search.py)
                                                 -> Response Generation (persona/level aware)
                                                 -> Frontend
```

`CricketAIService.ask(question, persona=None, level=None)` is the single
entry point. It is wrapped in its own try/except so a bug in one intent
handler can't crash the endpoint, and `AIAskAPIView` wraps its chat-history
bookkeeping the same way — the assistant should never return anything but a
well-formed JSON response.

Recognised intents: `TOP_RUNS`, `TOP_WICKETS`, `TEAM_STANDINGS`, `TEAM_INFO`,
`PLAYER_INFO`, `MATCH_INFO`, `TEAM_COMPARISON`, `PLAYER_COMPARISON`,
`STATISTICS`, `ARTICLE_SEARCH`, `GENERAL_CRICKET`, `UNKNOWN`.

## 15. Troubleshooting

### "python is not recognized"

Try `python --version` and `py --version` — use whichever your system
recognizes consistently.

### pip errors

Always use `py -m pip install -r requirements.txt` rather than a bare `pip`.
On macOS with Homebrew Python you may need
`python3 -m pip install -r requirements.txt --break-system-packages`.

### Migration errors

Re-run `py manage.py makemigrations` then `py manage.py migrate`. If
migrations get out of sync, delete `db.sqlite3` and everything under
`core/migrations/` except `__init__.py`, then redo both, then `seed_data`.

### "Port already in use"

`py manage.py runserver 8001`

### The AI Assistant chat box doesn't respond / shows an error

1. Open your browser's DevTools console (F12) on the `/ai/` page — the chat
   widget logs the real error there (network failure, HTTP status, or a
   non-JSON response), not just a generic message.
2. Check the terminal running `py manage.py runserver` for a traceback —
   `LOGGING` is configured so unhandled errors print there.
3. Confirm you ran `py manage.py migrate` and `py manage.py seed_data`
   first — an empty database still answers (e.g. "no player data loaded
   yet"), but migrations must exist for the API to respond at all.
4. Test the API directly, bypassing the browser:
   ```bash
   curl -X POST http://127.0.0.1:8000/api/ai/ask/ \
     -H "Content-Type: application/json" \
     -d '{"question": "Who has scored the most runs?"}'
   ```
   You should get back a JSON body with `"success": true`. If you get an
   HTML page instead, the traceback in the runserver terminal will show
   exactly what broke.
5. Make sure you're browsing `http://127.0.0.1:8000/`, not a different host
   name, so it matches `DJANGO_ALLOWED_HOSTS` in `.env`.

### Tests won't run

Use `py -m pytest`, not a bare `pytest`, and make sure `.env` exists and
migrations have been applied.
