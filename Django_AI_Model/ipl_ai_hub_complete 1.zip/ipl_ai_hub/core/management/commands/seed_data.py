"""
Management command that seeds the database with realistic demo IPL data
so the project is immediately usable after `py manage.py migrate`.

Usage:
    py manage.py seed_data
    py manage.py seed_data --flush   # wipe existing demo data first
"""
import datetime
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from core.models import Article, Match, Player, Tag, Team

TEAMS = [
    dict(name='Chennai Super Kings', short_name='CSK', city='Chennai',
         matches_played=10, wins=7, losses=3, no_result=0, points=14, net_run_rate=Decimal('0.652')),
    dict(name='Mumbai Indians', short_name='MI', city='Mumbai',
         matches_played=10, wins=6, losses=4, no_result=0, points=12, net_run_rate=Decimal('0.410')),
    dict(name='Royal Challengers Bengaluru', short_name='RCB', city='Bengaluru',
         matches_played=10, wins=6, losses=4, no_result=0, points=12, net_run_rate=Decimal('0.298')),
    dict(name='Kolkata Knight Riders', short_name='KKR', city='Kolkata',
         matches_played=10, wins=6, losses=3, no_result=1, points=13, net_run_rate=Decimal('0.512')),
    dict(name='Delhi Capitals', short_name='DC', city='Delhi',
         matches_played=10, wins=5, losses=5, no_result=0, points=10, net_run_rate=Decimal('-0.120')),
    dict(name='Punjab Kings', short_name='PBKS', city='Mohali',
         matches_played=10, wins=4, losses=6, no_result=0, points=8, net_run_rate=Decimal('-0.245')),
    dict(name='Rajasthan Royals', short_name='RR', city='Jaipur',
         matches_played=10, wins=5, losses=4, no_result=1, points=11, net_run_rate=Decimal('0.155')),
    dict(name='Sunrisers Hyderabad', short_name='SRH', city='Hyderabad',
         matches_played=10, wins=4, losses=6, no_result=0, points=8, net_run_rate=Decimal('-0.310')),
    dict(name='Gujarat Titans', short_name='GT', city='Ahmedabad',
         matches_played=10, wins=6, losses=4, no_result=0, points=12, net_run_rate=Decimal('0.201')),
    dict(name='Lucknow Super Giants', short_name='LSG', city='Lucknow',
         matches_played=10, wins=5, losses=5, no_result=0, points=10, net_run_rate=Decimal('-0.055')),
]

# (name, role, runs, wickets, strike_rate, economy_rate, matches, bat_avg, bowl_avg, sixes, fours, highest_score, best_bowling, maidens)
PLAYERS_BY_TEAM = {
    'CSK': [
        ('Ruturaj Gaikwad', 'BATTER', 420, 0, 142.5, 0, 10, 52.5, 0, 18, 40, '108*', '0/0', 0),
        ('MS Dhoni', 'WICKETKEEPER', 210, 0, 158.2, 0, 9, 42.0, 0, 15, 10, '54*', '0/0', 0),
        ('Devon Conway', 'BATTER', 385, 0, 138.0, 0, 10, 48.1, 0, 12, 34, '92', '0/0', 0),
        ('Ravindra Jadeja', 'ALL_ROUNDER', 180, 14, 145.0, 7.8, 10, 30.0, 22.4, 8, 12, '45*', '3/20', 1),
        ('Deepak Chahar', 'BOWLER', 20, 12, 110.0, 8.1, 9, 10.0, 24.1, 0, 2, '12', '4/17', 0),
        ('Matheesha Pathirana', 'BOWLER', 5, 15, 90.0, 7.2, 10, 5.0, 19.8, 0, 0, '5*', '4/24', 0),
    ],
    'MI': [
        ('Rohit Sharma', 'BATTER', 360, 0, 140.1, 0, 10, 40.0, 0, 20, 30, '105*', '0/0', 0),
        ('Ishan Kishan', 'WICKETKEEPER', 310, 0, 135.6, 0, 10, 34.4, 0, 14, 28, '89', '0/0', 0),
        ('Suryakumar Yadav', 'BATTER', 400, 0, 150.3, 0, 10, 50.0, 0, 16, 32, '98*', '0/0', 0),
        ('Hardik Pandya', 'ALL_ROUNDER', 220, 10, 148.2, 8.5, 10, 27.5, 26.0, 10, 14, '55', '3/25', 0),
        ('Jasprit Bumrah', 'BOWLER', 10, 18, 85.0, 6.4, 10, 5.0, 17.2, 0, 1, '8', '5/10', 1),
        ('Piyush Chawla', 'BOWLER', 15, 9, 95.0, 8.0, 9, 7.5, 27.0, 0, 1, '10', '3/28', 0),
    ],
    'RCB': [
        ('Virat Kohli', 'BATTER', 460, 0, 146.8, 0, 10, 57.5, 0, 14, 46, '113*', '0/0', 0),
        ('Faf du Plessis', 'BATTER', 350, 0, 139.7, 0, 10, 38.9, 0, 15, 30, '96', '0/0', 0),
        ('Glenn Maxwell', 'ALL_ROUNDER', 280, 8, 165.4, 8.9, 9, 35.0, 30.1, 18, 16, '83*', '2/18', 0),
        ('Dinesh Karthik', 'WICKETKEEPER', 190, 0, 175.2, 0, 9, 31.6, 0, 12, 8, '55*', '0/0', 0),
        ('Mohammed Siraj', 'BOWLER', 8, 16, 80.0, 8.2, 10, 4.0, 20.5, 0, 0, '6', '4/21', 0),
        ('Yuzvendra Chahal', 'BOWLER', 5, 13, 75.0, 7.6, 10, 3.5, 22.9, 0, 0, '4', '4/25', 0),
    ],
    'KKR': [
        ('Shreyas Iyer', 'BATTER', 340, 0, 137.9, 0, 10, 42.5, 0, 13, 28, '88', '0/0', 0),
        ('Rinku Singh', 'BATTER', 300, 0, 149.3, 0, 10, 50.0, 0, 12, 22, '67*', '0/0', 0),
        ('Andre Russell', 'ALL_ROUNDER', 260, 12, 178.6, 9.1, 9, 37.1, 21.5, 22, 14, '75*', '3/15', 0),
        ('Sunil Narine', 'ALL_ROUNDER', 200, 15, 168.2, 6.5, 10, 25.0, 18.0, 14, 12, '54', '4/20', 0),
        ('Varun Chakravarthy', 'BOWLER', 5, 14, 70.0, 7.0, 10, 2.5, 19.0, 0, 0, '4', '4/16', 1),
        ('Mitchell Starc', 'BOWLER', 12, 17, 95.0, 7.9, 10, 6.0, 18.5, 0, 1, '10*', '4/23', 0),
    ],
}

PLAYERS_BY_TEAM.update({
    'DC': [
        ('David Warner', 'BATTER', 380, 0, 143.2, 0, 10, 42.2, 0, 16, 38, '95', '0/0', 0),
        ('Prithvi Shaw', 'BATTER', 290, 0, 152.6, 0, 9, 32.2, 0, 14, 26, '71', '0/0', 0),
        ('Axar Patel', 'ALL_ROUNDER', 180, 11, 140.0, 7.4, 10, 25.7, 23.6, 6, 10, '40', '3/16', 1),
        ('Rishabh Pant', 'WICKETKEEPER', 310, 0, 155.8, 0, 9, 44.3, 0, 15, 20, '88*', '0/0', 0),
        ('Kuldeep Yadav', 'BOWLER', 10, 13, 85.0, 7.7, 10, 5.0, 23.8, 0, 1, '8', '4/22', 0),
        ('Anrich Nortje', 'BOWLER', 6, 12, 70.0, 8.3, 9, 3.0, 24.5, 0, 0, '5', '3/25', 0),
    ],
    'PBKS': [
        ('Shikhar Dhawan', 'BATTER', 330, 0, 132.5, 0, 10, 36.7, 0, 10, 34, '86', '0/0', 0),
        ('Liam Livingstone', 'ALL_ROUNDER', 250, 6, 172.4, 9.5, 9, 31.3, 32.0, 20, 12, '73', '2/20', 0),
        ('Sam Curran', 'ALL_ROUNDER', 210, 11, 150.2, 8.8, 10, 26.3, 25.4, 8, 14, '55*', '3/23', 0),
        ('Jitesh Sharma', 'WICKETKEEPER', 220, 0, 160.1, 0, 9, 31.4, 0, 11, 14, '52*', '0/0', 0),
        ('Kagiso Rabada', 'BOWLER', 8, 15, 80.0, 8.0, 10, 4.0, 21.1, 0, 0, '6', '4/24', 0),
        ('Arshdeep Singh', 'BOWLER', 5, 14, 65.0, 8.4, 10, 2.5, 22.7, 0, 0, '4', '3/22', 0),
    ],
    'RR': [
        ('Yashasvi Jaiswal', 'BATTER', 410, 0, 148.6, 0, 10, 45.5, 0, 18, 40, '98', '0/0', 0),
        ('Sanju Samson', 'WICKETKEEPER', 350, 0, 152.3, 0, 10, 43.7, 0, 16, 28, '86*', '0/0', 0),
        ('Jos Buttler', 'BATTER', 390, 0, 156.8, 0, 9, 48.7, 0, 20, 32, '107*', '0/0', 0),
        ('Ravichandran Ashwin', 'ALL_ROUNDER', 120, 10, 120.0, 6.9, 10, 20.0, 24.0, 2, 8, '28', '3/22', 1),
        ('Trent Boult', 'BOWLER', 10, 16, 80.0, 7.3, 10, 5.0, 19.4, 0, 1, '9', '4/18', 0),
        ('Kuldeep Sen', 'BOWLER', 4, 12, 60.0, 7.8, 9, 2.0, 23.0, 0, 0, '4', '3/24', 0),
    ],
    'SRH': [
        ('Travis Head', 'BATTER', 400, 0, 168.9, 0, 9, 50.0, 0, 22, 38, '102', '0/0', 0),
        ('Abhishek Sharma', 'ALL_ROUNDER', 320, 5, 172.5, 9.8, 10, 35.6, 34.0, 20, 24, '80', '2/24', 0),
        ('Heinrich Klaasen', 'WICKETKEEPER', 340, 0, 175.3, 0, 9, 48.6, 0, 24, 18, '80*', '0/0', 0),
        ('Pat Cummins', 'ALL_ROUNDER', 90, 12, 145.0, 8.6, 10, 15.0, 22.1, 4, 6, '30', '3/24', 0),
        ('Bhuvneshwar Kumar', 'BOWLER', 15, 11, 100.0, 7.9, 10, 7.5, 26.0, 0, 1, '11', '3/15', 0),
        ('T Natarajan', 'BOWLER', 4, 10, 60.0, 8.6, 9, 2.0, 27.5, 0, 0, '4', '3/30', 0),
    ],
    'GT': [
        ('Shubman Gill', 'BATTER', 420, 0, 141.7, 0, 10, 52.5, 0, 14, 42, '104', '0/0', 0),
        ('Wriddhiman Saha', 'WICKETKEEPER', 180, 0, 130.4, 0, 8, 25.7, 0, 6, 16, '48', '0/0', 0),
        ('Rashid Khan', 'ALL_ROUNDER', 130, 15, 155.0, 6.2, 10, 21.7, 16.5, 6, 6, '31*', '4/24', 1),
        ('Vijay Shankar', 'ALL_ROUNDER', 200, 9, 142.0, 8.7, 9, 28.6, 25.0, 8, 12, '50', '2/18', 0),
        ('Mohammed Shami', 'BOWLER', 6, 17, 75.0, 7.5, 10, 3.0, 18.0, 0, 0, '5', '5/18', 0),
        ('Josh Little', 'BOWLER', 3, 11, 55.0, 8.5, 9, 1.5, 25.0, 0, 0, '3', '3/26', 0),
    ],
    'LSG': [
        ('KL Rahul', 'WICKETKEEPER', 400, 0, 136.8, 0, 10, 50.0, 0, 12, 40, '98*', '0/0', 0),
        ('Quinton de Kock', 'BATTER', 340, 0, 140.5, 0, 9, 42.5, 0, 14, 30, '81', '0/0', 0),
        ('Marcus Stoinis', 'ALL_ROUNDER', 250, 7, 148.9, 9.0, 10, 31.3, 28.0, 12, 14, '62*', '2/20', 0),
        ('Nicholas Pooran', 'WICKETKEEPER', 300, 0, 170.6, 0, 9, 42.9, 0, 20, 16, '75*', '0/0', 0),
        ('Ravi Bishnoi', 'BOWLER', 8, 12, 80.0, 7.4, 10, 4.0, 21.9, 0, 0, '7', '3/20', 0),
        ('Mohsin Khan', 'BOWLER', 2, 10, 40.0, 7.6, 8, 1.0, 24.0, 0, 0, '2', '3/25', 0),
    ],
})

VENUES = [
    'MA Chidambaram Stadium, Chennai',
    'Wankhede Stadium, Mumbai',
    'M Chinnaswamy Stadium, Bengaluru',
    'Eden Gardens, Kolkata',
    'Arun Jaitley Stadium, Delhi',
    'Narendra Modi Stadium, Ahmedabad',
    'Sawai Mansingh Stadium, Jaipur',
    'Rajiv Gandhi International Stadium, Hyderabad',
    'Punjab Cricket Association Stadium, Mohali',
    'BRSABV Ekana Stadium, Lucknow',
]

ARTICLES = [
    dict(title='CSK Continue Their Dominant Run at Chepauk', category='TEAMS',
         summary='Chennai Super Kings extend their unbeaten home record this season.',
         tags=['CSK', 'IPL', 'Analysis']),
    dict(title='Virat Kohli Reaches Yet Another Milestone', category='PLAYERS',
         summary="Kohli's consistency continues to set the standard for modern batting.",
         tags=['RCB', 'Virat Kohli', 'Players']),
    dict(title='Understanding Net Run Rate: A Complete Guide', category='STATISTICS',
         summary='Everything you need to know about how NRR is calculated and why it matters.',
         tags=['NRR', 'Statistics', 'Points Table']),
    dict(title='How the AI Cricket Assistant Understands Your Questions', category='AI_CRICKET',
         summary='A look under the hood at the intent-detection engine powering IPL AI Hub.',
         tags=['AI', 'Technology']),
    dict(title='Race for the Playoffs: Who Needs What', category='ANALYSIS',
         summary='A data-driven look at each team’s route to the final four.',
         tags=['Playoffs', 'Analysis', 'Points Table']),
    dict(title="Rohit Sharma's Captaincy Legacy at Mumbai Indians", category='PLAYERS',
         summary='Looking back at years of leadership from one of the format’s greats.',
         tags=['MI', 'Rohit Sharma']),
    dict(title='Top 5 Bowling Performances of the Season So Far', category='STATISTICS',
         summary='The standout spells that have defined this year’s tournament.',
         tags=['Bowling', 'Statistics']),
    dict(title="Gujarat Titans' Rise: The Rashid Khan Effect", category='TEAMS',
         summary='How a smart auction strategy and a world-class spinner built a contender.',
         tags=['GT', 'Rashid Khan']),
    dict(title='IPL Playoff Format Explained', category='IPL',
         summary='A simple breakdown of Qualifier 1, Eliminator, Qualifier 2, and the Final.',
         tags=['Playoffs', 'IPL']),
    dict(title='Weekly Roundup: Biggest Moments From the Latest Round', category='NEWS',
         summary='Catch up on the results, milestones, and talking points from the week.',
         tags=['News', 'IPL']),
    dict(title='Data Deep Dive: Powerplay Strike Rates Across the League', category='STATISTICS',
         summary='Which teams are attacking hardest in the first six overs this season.',
         tags=['Statistics', 'Analysis']),
    dict(title="Sunrisers Hyderabad's High-Risk, High-Reward Batting Approach", category='ANALYSIS',
         summary='Why SRH’s aggressive top order has become the league’s most talked-about strategy.',
         tags=['SRH', 'Analysis']),
]

class Command(BaseCommand):
    help = 'Seed the database with realistic demo IPL data (teams, players, matches, articles).'

    def add_arguments(self, parser):
        parser.add_argument(
            '--flush', action='store_true',
            help='Delete existing Team/Player/Match/Article data before seeding.',
        )

    def handle(self, *args, **options):
        with transaction.atomic():
            if options['flush']:
                self.stdout.write('Flushing existing demo data...')
                Match.objects.all().delete()
                Player.objects.all().delete()
                Team.objects.all().delete()
                Article.objects.all().delete()
                Tag.objects.all().delete()

            teams = self._seed_teams()
            self._seed_players(teams)
            self._seed_matches(teams)
            self._seed_articles()

        self.stdout.write(self.style.SUCCESS('Seed data loaded successfully.'))

    def _seed_teams(self):
        teams = {}
        for data in TEAMS:
            team, created = Team.objects.update_or_create(
                short_name=data['short_name'], defaults=data,
            )
            teams[team.short_name] = team
            self.stdout.write(f'  {"Created" if created else "Updated"} team {team.name}')
        return teams

    def _seed_players(self, teams):
        for short_name, players in PLAYERS_BY_TEAM.items():
            team = teams[short_name]
            for (name, role, runs, wickets, sr, econ, matches, bat_avg, bowl_avg,
                 sixes, fours, highest, best_bowl, maidens) in players:
                Player.objects.update_or_create(
                    name=name, team=team,
                    defaults=dict(
                        role=role, runs=runs, wickets=wickets,
                        strike_rate=Decimal(str(sr)), economy_rate=Decimal(str(econ)),
                        matches_played=matches, batting_average=Decimal(str(bat_avg)),
                        bowling_average=Decimal(str(bowl_avg)), sixes=sixes, fours=fours,
                        highest_score=highest, best_bowling=best_bowl, maidens=maidens,
                        description=f'{name} plays for {team.name} as a {role.replace("_", "-").title()}.',
                    ),
                )
        self.stdout.write(f'  Seeded players for {len(PLAYERS_BY_TEAM)} teams')

    def _seed_matches(self, teams):
        team_list = list(teams.values())
        today = timezone.localdate()
        match_number = 1

        completed_pairs = []
        for i in range(len(team_list)):
            for j in range(i + 1, len(team_list)):
                completed_pairs.append((team_list[i], team_list[j]))
        completed_pairs = completed_pairs[:24]

        for idx, (home, away) in enumerate(completed_pairs):
            match_date = today - datetime.timedelta(days=(len(completed_pairs) - idx) * 2)
            winner = home if (home.points, home.net_run_rate) >= (away.points, away.net_run_rate) else away
            home_score = 165 + (idx % 5) * 7
            away_score = 150 + (idx % 4) * 6
            Match.objects.update_or_create(
                match_number=match_number,
                defaults=dict(
                    home_team=home, away_team=away,
                    date=match_date, time=datetime.time(19, 30),
                    venue=VENUES[idx % len(VENUES)],
                    status=Match.Status.COMPLETED,
                    score=f'{home.short_name} {home_score}/6 (20) vs {away.short_name} {away_score}/8 (20)',
                    winner=winner,
                    result=f'{winner.short_name} won by {abs(home_score - away_score)} runs',
                ),
            )
            match_number += 1

        live_home, live_away = team_list[0], team_list[1]
        Match.objects.update_or_create(
            match_number=match_number,
            defaults=dict(
                home_team=live_home, away_team=live_away,
                date=today, time=datetime.time(19, 30),
                venue=VENUES[0], status=Match.Status.LIVE,
                score=f'{live_home.short_name} 142/3 (16.2)', result='',
            ),
        )
        match_number += 1

        upcoming_pairs = [(team_list[i], team_list[(i + 3) % len(team_list)]) for i in range(6)]
        for idx, (home, away) in enumerate(upcoming_pairs):
            match_date = today + datetime.timedelta(days=idx * 2 + 1)
            Match.objects.update_or_create(
                match_number=match_number,
                defaults=dict(
                    home_team=home, away_team=away,
                    date=match_date, time=datetime.time(19, 30),
                    venue=VENUES[(idx + 2) % len(VENUES)],
                    status=Match.Status.UPCOMING,
                ),
            )
            match_number += 1

        self.stdout.write(f'  Seeded {match_number - 1} matches')

    def _seed_articles(self):
        base_date = timezone.now() - datetime.timedelta(days=len(ARTICLES))
        for idx, data in enumerate(ARTICLES):
            article, _ = Article.objects.update_or_create(
                title=data['title'],
                defaults=dict(
                    summary=data['summary'],
                    content=(data['summary'] + ' ' + (
                        'This is placeholder-free demo editorial content generated for the '
                        'IPL AI Hub seed data set, written to read like a short cricket news '
                        'piece so the articles module has something realistic to search and filter.'
                    )),
                    category=data['category'],
                    author='IPL AI Hub Staff',
                    published_date=base_date + datetime.timedelta(days=idx),
                    source_url='',
                ),
            )
            tags = [Tag.objects.get_or_create(name=t)[0] for t in data['tags']]
            article.tags.set(tags)
        self.stdout.write(f'  Seeded {len(ARTICLES)} articles')
