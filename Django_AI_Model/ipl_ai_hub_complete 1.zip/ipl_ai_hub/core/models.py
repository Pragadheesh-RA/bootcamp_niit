"""
Core data models for the IPL AI Hub platform.

Includes teams, players, matches, articles/content, and the chat models
used by the AI Cricket Assistant.
"""
from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class TimeStampedModel(models.Model):
    """Abstract base class adding created/updated timestamps."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Team(TimeStampedModel):
    name = models.CharField(max_length=100, unique=True)
    short_name = models.CharField(max_length=10, unique=True)
    city = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='teams/logos/', blank=True, null=True)
    matches_played = models.PositiveIntegerField(default=0)
    wins = models.PositiveIntegerField(default=0)
    losses = models.PositiveIntegerField(default=0)
    no_result = models.PositiveIntegerField(default=0)
    points = models.PositiveIntegerField(default=0)
    net_run_rate = models.DecimalField(max_digits=5, decimal_places=3, default=0)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ['-points', '-net_run_rate', 'name']
        indexes = [
            models.Index(fields=['-points', '-net_run_rate']),
            models.Index(fields=['short_name']),
        ]

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('core:team_detail', args=[self.pk])

    @property
    def nrr(self):
        return self.net_run_rate


class Player(TimeStampedModel):
    class Role(models.TextChoices):
        BATTER = 'BATTER', 'Batter'
        BOWLER = 'BOWLER', 'Bowler'
        ALL_ROUNDER = 'ALL_ROUNDER', 'All-rounder'
        WICKETKEEPER = 'WICKETKEEPER', 'Wicketkeeper'

    name = models.CharField(max_length=100)
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='players')
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.BATTER)
    image = models.ImageField(upload_to='players/images/', blank=True, null=True)

    runs = models.PositiveIntegerField(default=0)
    wickets = models.PositiveIntegerField(default=0)
    strike_rate = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    economy_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    matches_played = models.PositiveIntegerField(default=0)
    batting_average = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    bowling_average = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    sixes = models.PositiveIntegerField(default=0)
    fours = models.PositiveIntegerField(default=0)
    highest_score = models.CharField(max_length=10, blank=True, default='0')
    best_bowling = models.CharField(max_length=10, blank=True, default='0/0')
    maidens = models.PositiveIntegerField(default=0)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ['-runs', 'name']
        indexes = [
            models.Index(fields=['-runs']),
            models.Index(fields=['-wickets']),
            models.Index(fields=['-strike_rate']),
            models.Index(fields=['role']),
        ]

    def __str__(self):
        return f'{self.name} ({self.team.short_name})'

    def get_absolute_url(self):
        return reverse('core:player_detail', args=[self.pk])


class Match(TimeStampedModel):
    class Status(models.TextChoices):
        UPCOMING = 'UPCOMING', 'Upcoming'
        LIVE = 'LIVE', 'Live'
        COMPLETED = 'COMPLETED', 'Completed'
        ABANDONED = 'ABANDONED', 'Abandoned'

    match_number = models.PositiveIntegerField(unique=True)
    home_team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='home_matches')
    away_team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='away_matches')
    date = models.DateField()
    time = models.TimeField()
    venue = models.CharField(max_length=150)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.UPCOMING)
    score = models.CharField(max_length=255, blank=True)
    winner = models.ForeignKey(
        Team, on_delete=models.SET_NULL, related_name='wins_list', blank=True, null=True
    )
    result = models.TextField(blank=True)

    class Meta:
        ordering = ['date', 'time']
        indexes = [
            models.Index(fields=['date']),
            models.Index(fields=['status']),
        ]
        constraints = [
            models.CheckConstraint(
                check=~models.Q(home_team=models.F('away_team')),
                name='match_home_away_teams_differ',
            )
        ]

    def __str__(self):
        return f'Match {self.match_number}: {self.home_team.short_name} vs {self.away_team.short_name}'

    def get_absolute_url(self):
        return reverse('core:match_detail', args=[self.pk])


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=60, unique=True, blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Article(TimeStampedModel):
    class Category(models.TextChoices):
        IPL = 'IPL', 'IPL'
        TEAMS = 'TEAMS', 'Teams'
        PLAYERS = 'PLAYERS', 'Players'
        MATCHES = 'MATCHES', 'Matches'
        ANALYSIS = 'ANALYSIS', 'Analysis'
        STATISTICS = 'STATISTICS', 'Statistics'
        AI_CRICKET = 'AI_CRICKET', 'AI & Cricket'
        NEWS = 'NEWS', 'News'

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.CharField(max_length=500)
    content = models.TextField()
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.NEWS)
    author = models.CharField(max_length=100, default='IPL AI Hub Staff')
    image = models.ImageField(upload_to='articles/images/', blank=True, null=True)
    published_date = models.DateTimeField()
    source_url = models.URLField(blank=True)
    tags = models.ManyToManyField(Tag, related_name='articles', blank=True)

    class Meta:
        ordering = ['-published_date']
        indexes = [
            models.Index(fields=['category']),
            models.Index(fields=['-published_date']),
        ]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            while Article.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                counter += 1
                slug = f'{base_slug}-{counter}'
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('core:article_detail', args=[self.slug])


class ChatSession(TimeStampedModel):
    class Persona(models.TextChoices):
        CASUAL_FAN = 'CASUAL_FAN', 'Casual Fan'
        BEGINNER = 'BEGINNER', 'Beginner'
        STUDENT = 'STUDENT', 'Student'
        CRICKET_ANALYST = 'CRICKET_ANALYST', 'Cricket Analyst'
        DATA_ANALYST = 'DATA_ANALYST', 'Data Analyst'
        COACH = 'COACH', 'Coach'
        RESEARCHER = 'RESEARCHER', 'Researcher'

    class Level(models.TextChoices):
        BEGINNER = 'BEGINNER', 'Beginner'
        INTERMEDIATE = 'INTERMEDIATE', 'Intermediate'
        ADVANCED = 'ADVANCED', 'Advanced'
        EXPERT = 'EXPERT', 'Expert'

    session_key = models.CharField(max_length=64, unique=True, db_index=True)
    persona = models.CharField(max_length=20, choices=Persona.choices, default=Persona.CASUAL_FAN)
    level = models.CharField(max_length=20, choices=Level.choices, default=Level.BEGINNER)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Session {self.session_key}'


class ChatMessage(TimeStampedModel):
    class Role(models.TextChoices):
        USER = 'USER', 'User'
        ASSISTANT = 'ASSISTANT', 'Assistant'

    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name='messages')
    role = models.CharField(max_length=10, choices=Role.choices)
    message = models.TextField()
    intent = models.CharField(max_length=30, blank=True)

    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['session', 'created_at']),
        ]

    def __str__(self):
        return f'{self.role}: {self.message[:40]}'
