from django.contrib import admin

from core.models import Article, ChatMessage, ChatSession, Match, Player, Tag, Team


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'short_name', 'city', 'matches_played', 'wins', 'losses', 'points', 'net_run_rate')
    search_fields = ('name', 'short_name', 'city')
    list_filter = ('city',)
    ordering = ('-points', '-net_run_rate')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ('name', 'team', 'role', 'runs', 'wickets', 'strike_rate', 'economy_rate', 'matches_played')
    search_fields = ('name', 'team__name', 'team__short_name')
    list_filter = ('role', 'team')
    ordering = ('-runs',)
    readonly_fields = ('created_at', 'updated_at')
    autocomplete_fields = ('team',)


@admin.register(Match)
class MatchAdmin(admin.ModelAdmin):
    list_display = ('match_number', 'home_team', 'away_team', 'date', 'time', 'venue', 'status', 'winner')
    search_fields = ('venue', 'home_team__name', 'away_team__name')
    list_filter = ('status', 'date')
    ordering = ('date', 'time')
    readonly_fields = ('created_at', 'updated_at')
    autocomplete_fields = ('home_team', 'away_team', 'winner')


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'author', 'published_date')
    search_fields = ('title', 'summary', 'content', 'author')
    list_filter = ('category', 'author')
    ordering = ('-published_date',)
    readonly_fields = ('created_at', 'updated_at')
    prepopulated_fields = {'slug': ('title',)}
    filter_horizontal = ('tags',)


class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 0
    readonly_fields = ('role', 'message', 'intent', 'created_at')
    can_delete = False


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ('session_key', 'persona', 'level', 'created_at')
    search_fields = ('session_key',)
    list_filter = ('persona', 'level')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at')
    inlines = [ChatMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('session', 'role', 'intent', 'created_at')
    search_fields = ('message', 'session__session_key')
    list_filter = ('role', 'intent')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at')


admin.site.site_header = 'IPL AI Hub Administration'
admin.site.site_title = 'IPL AI Hub Admin'
admin.site.index_title = 'Manage cricket data, content, and AI chat sessions'
