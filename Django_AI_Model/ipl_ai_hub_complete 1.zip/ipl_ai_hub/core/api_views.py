"""REST API views for the IPL AI Hub platform."""
import logging
import uuid

from django.db import IntegrityError
from rest_framework import filters, status, viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from core.models import Article, ChatMessage, ChatSession, Match, Player, Team
from core.serializers import (
    AIAskRequestSerializer,
    ArticleSerializer,
    MatchSerializer,
    PlayerSerializer,
    StandingSerializer,
    TeamSerializer,
)
from core.services import search as search_service
from core.services import statistics as stats_service
from core.services.ai import get_ai_service

logger = logging.getLogger('core')


class TeamViewSet(viewsets.ModelViewSet):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'short_name', 'city']
    ordering_fields = ['points', 'net_run_rate', 'name', 'wins']

    def destroy(self, request, *args, **kwargs):
        try:
            return super().destroy(request, *args, **kwargs)
        except IntegrityError:
            return Response(
                {'detail': 'This team cannot be deleted while it has related players or matches.'},
                status=status.HTTP_409_CONFLICT,
            )


class PlayerViewSet(viewsets.ModelViewSet):
    queryset = Player.objects.select_related('team').all()
    serializer_class = PlayerSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'team__name', 'team__short_name']
    ordering_fields = ['runs', 'wickets', 'strike_rate', 'economy_rate', 'name']

    def get_queryset(self):
        qs = super().get_queryset()
        team = self.request.query_params.get('team')
        role = self.request.query_params.get('role')
        if team:
            qs = qs.filter(team__short_name__iexact=team)
        if role:
            qs = qs.filter(role__iexact=role)
        return qs


class MatchViewSet(viewsets.ModelViewSet):
    queryset = Match.objects.select_related('home_team', 'away_team', 'winner').all()
    serializer_class = MatchSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['venue', 'home_team__name', 'away_team__name']
    ordering_fields = ['date', 'time', 'match_number']

    def get_queryset(self):
        qs = super().get_queryset()
        status_param = self.request.query_params.get('status')
        team = self.request.query_params.get('team')
        date = self.request.query_params.get('date')
        if status_param:
            qs = qs.filter(status__iexact=status_param)
        if team:
            qs = qs.filter(home_team__short_name__iexact=team) | qs.filter(away_team__short_name__iexact=team)
        if date:
            qs = qs.filter(date=date)
        return qs


class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.prefetch_related('tags').all()
    serializer_class = ArticleSerializer
    lookup_field = 'slug'
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'summary', 'content']
    ordering_fields = ['published_date', 'title']

    def get_queryset(self):
        qs = super().get_queryset()
        category = self.request.query_params.get('category')
        tag = self.request.query_params.get('tag')
        if category:
            qs = qs.filter(category__iexact=category)
        if tag:
            qs = qs.filter(tags__name__iexact=tag)
        return qs


class StandingsAPIView(APIView):
    def get(self, request):
        teams = stats_service.team_standings()
        serializer = StandingSerializer(teams, many=True)
        return Response({'success': True, 'standings': serializer.data})


class StatisticsAPIView(APIView):
    def get(self, request):
        return Response({
            'success': True,
            'batting': _serialize_players(stats_service.batting_statistics()),
            'bowling': _serialize_players(stats_service.bowling_statistics()),
        })


def _serialize_players(stat_dict):
    out = {}
    for key, players in stat_dict.items():
        out[key] = [
            {
                'id': p.id,
                'name': p.name,
                'team': p.team.short_name,
                'runs': p.runs,
                'wickets': p.wickets,
                'strike_rate': str(p.strike_rate),
                'economy_rate': str(p.economy_rate),
                'batting_average': str(p.batting_average),
                'bowling_average': str(p.bowling_average),
                'sixes': p.sixes,
                'fours': p.fours,
                'maidens': p.maidens,
            }
            for p in players
        ]
    return out


class SearchAPIView(APIView):
    def get(self, request):
        query = request.query_params.get('q', '')
        results = search_service.global_search(query)
        return Response({
            'success': True,
            'query': results['query'],
            'teams': TeamSerializer(results['teams'], many=True).data,
            'players': PlayerSerializer(results['players'], many=True).data,
            'matches': MatchSerializer(results['matches'], many=True).data,
            'articles': ArticleSerializer(results['articles'], many=True).data,
        })


class AIAskAPIView(APIView):
    """
    POST /api/ai/ask/ -- the AI Cricket Assistant endpoint.

    This view is deliberately defensive: `CricketAIService.ask()` already
    catches its own internal errors, but the session/chat-history bookkeeping
    below is wrapped too, so a database hiccup while logging chat history can
    never turn into an unhandled 500 that the frontend can't parse as JSON.
    """

    def post(self, request):
        serializer = AIAskRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {'success': False, 'errors': serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )

        validated = serializer.validated_data
        question = validated['question']
        persona = validated.get('persona') or 'CASUAL_FAN'
        level = validated.get('level') or 'BEGINNER'
        session_key = validated.get('session_key') or uuid.uuid4().hex

        ai_service = get_ai_service()
        result = ai_service.ask(question, persona=persona, level=level)

        try:
            session, _ = ChatSession.objects.get_or_create(
                session_key=session_key,
                defaults={'persona': persona, 'level': level},
            )
            if session.persona != persona or session.level != level:
                session.persona = persona
                session.level = level
                session.save(update_fields=['persona', 'level'])

            ChatMessage.objects.create(session=session, role=ChatMessage.Role.USER, message=question)
            ChatMessage.objects.create(
                session=session,
                role=ChatMessage.Role.ASSISTANT,
                message=result['answer'],
                intent=result['intent'],
            )
        except Exception:  # noqa: BLE001
            # Chat history is a nice-to-have; never let a logging failure
            # stop the user from getting their answer back.
            logger.exception('Failed to persist chat history for session_key=%r', session_key)

        result['session_key'] = session_key
        return Response(result, status=status.HTTP_200_OK)


@api_view(['GET'])
def ai_welcome(request):
    ai_service = get_ai_service()
    return Response({
        'success': True,
        'message': ai_service.welcome_message(),
        'suggested_questions': ai_service.suggested_questions(),
    })
