"""Frontend (template-rendering) views for the IPL AI Hub platform."""
from django.core.paginator import Paginator
from django.middleware.csrf import get_token
from django.shortcuts import get_object_or_404, render

from core.models import Article, Match, Player, Team
from core.services import search as search_service
from core.services import statistics as stats_service
from core.services.ai import get_ai_service


def index(request):
    context = {
        'summary': stats_service.dashboard_summary(),
        'recent_matches': Match.objects.select_related('home_team', 'away_team')
        .filter(status=Match.Status.COMPLETED)
        .order_by('-date')[:5],
        'upcoming_matches': Match.objects.select_related('home_team', 'away_team')
        .filter(status=Match.Status.UPCOMING)
        .order_by('date')[:5],
        'standings': stats_service.team_standings()[:4],
    }
    return render(request, 'index.html', context)


def team_list(request):
    teams = Team.objects.all()
    query = request.GET.get('q', '').strip()
    city = request.GET.get('city', '').strip()
    if query:
        teams = teams.filter(name__icontains=query)
    if city:
        teams = teams.filter(city__iexact=city)
    cities = Team.objects.values_list('city', flat=True).distinct().order_by('city')
    context = {'teams': teams, 'query': query, 'city': city, 'cities': cities}
    return render(request, 'teams/list.html', context)


def team_detail(request, pk):
    team = get_object_or_404(Team, pk=pk)
    context = {
        'team': team,
        'players': team.players.all(),
        'home_matches': team.home_matches.select_related('away_team').order_by('-date')[:10],
        'away_matches': team.away_matches.select_related('home_team').order_by('-date')[:10],
    }
    return render(request, 'teams/detail.html', context)


def player_list(request):
    players = Player.objects.select_related('team').all()
    query = request.GET.get('q', '').strip()
    team = request.GET.get('team', '').strip()
    role = request.GET.get('role', '').strip()
    sort = request.GET.get('sort', '').strip()

    if query:
        players = players.filter(name__icontains=query)
    if team:
        players = players.filter(team__short_name__iexact=team)
    if role:
        players = players.filter(role__iexact=role)

    sort_map = {
        'runs': '-runs',
        'wickets': '-wickets',
        'strike_rate': '-strike_rate',
    }
    if sort in sort_map:
        players = players.order_by(sort_map[sort])

    paginator = Paginator(players, 24)
    page_obj = paginator.get_page(request.GET.get('page'))

    context = {
        'page_obj': page_obj,
        'players': page_obj.object_list,
        'query': query,
        'team': team,
        'role': role,
        'sort': sort,
        'teams': Team.objects.all(),
        'roles': Player.Role.choices,
    }
    return render(request, 'players/list.html', context)


def player_detail(request, pk):
    player = get_object_or_404(Player.objects.select_related('team'), pk=pk)
    context = {'player': player}
    return render(request, 'players/detail.html', context)


def match_list(request):
    matches = Match.objects.select_related('home_team', 'away_team', 'winner').all()
    status_filter = request.GET.get('status', '').strip()
    team = request.GET.get('team', '').strip()
    date = request.GET.get('date', '').strip()

    if status_filter:
        matches = matches.filter(status__iexact=status_filter)
    if team:
        matches = matches.filter(home_team__short_name__iexact=team) | matches.filter(
            away_team__short_name__iexact=team
        )
    if date:
        matches = matches.filter(date=date)

    context = {
        'matches': matches,
        'status_filter': status_filter,
        'team': team,
        'date': date,
        'teams': Team.objects.all(),
        'statuses': Match.Status.choices,
    }
    return render(request, 'matches/list.html', context)


def match_detail(request, pk):
    match = get_object_or_404(
        Match.objects.select_related('home_team', 'away_team', 'winner'), pk=pk
    )
    return render(request, 'matches/detail.html', {'match': match})


def standings(request):
    context = {'standings': stats_service.team_standings()}
    return render(request, 'standings/list.html', context)


def statistics(request):
    teams = stats_service.team_standings()[:8]
    top_scorers = stats_service.top_run_scorers(8)
    top_wickets = stats_service.top_wicket_takers(8)
    strike_rates = stats_service.highest_strike_rates(8)

    context = {
        'batting': stats_service.batting_statistics(10),
        'bowling': stats_service.bowling_statistics(10),
        'all_rounders': stats_service.best_all_rounders(10),
        'chart_team_points': {
            'labels': [t.short_name for t in teams],
            'values': [t.points for t in teams],
        },
        'chart_top_scorers': {
            'labels': [p.name for p in top_scorers],
            'values': [p.runs for p in top_scorers],
        },
        'chart_top_wickets': {
            'labels': [p.name for p in top_wickets],
            'values': [p.wickets for p in top_wickets],
        },
        'chart_wins_losses': {
            'labels': [t.short_name for t in teams],
            'wins': [t.wins for t in teams],
            'losses': [t.losses for t in teams],
        },
        'chart_strike_rates': {
            'labels': [p.name for p in strike_rates],
            'values': [float(p.strike_rate) for p in strike_rates],
        },
    }
    return render(request, 'statistics/list.html', context)


def article_list(request):
    articles = Article.objects.prefetch_related('tags').all()
    query = request.GET.get('q', '').strip()
    category = request.GET.get('category', '').strip()
    tag = request.GET.get('tag', '').strip()

    if query:
        articles = search_service.search_articles(query, limit=100, category=category or None, tag=tag or None)
    else:
        if category:
            articles = articles.filter(category__iexact=category)
        if tag:
            articles = articles.filter(tags__name__iexact=tag)

    paginator = Paginator(articles, 12)
    page_obj = paginator.get_page(request.GET.get('page'))

    context = {
        'page_obj': page_obj,
        'articles': page_obj.object_list,
        'query': query,
        'category': category,
        'tag': tag,
        'categories': Article.Category.choices,
    }
    return render(request, 'articles/list.html', context)


def article_detail(request, slug):
    article = get_object_or_404(Article.objects.prefetch_related('tags'), slug=slug)
    context = {
        'article': article,
        'related_articles': search_service.related_articles(article),
    }
    return render(request, 'articles/detail.html', context)


def ai_assistant(request):
    # Ensure the CSRF cookie is set on this page so the chat widget's fetch()
    # call always has a token available, even though the AI API itself does
    # not require authentication.
    get_token(request)
    ai_service = get_ai_service()
    context = {
        'welcome_message': ai_service.welcome_message(),
        'suggested_questions': ai_service.suggested_questions(),
    }
    return render(request, 'ai/chat.html', context)


def search_view(request):
    query = request.GET.get('q', '').strip()
    results = search_service.global_search(query) if query else None
    return render(request, 'search.html', {'query': query, 'results': results})
