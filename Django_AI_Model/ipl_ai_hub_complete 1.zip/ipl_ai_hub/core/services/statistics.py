"""
Statistics service.

Centralises all aggregate/statistical queries used by the dashboard,
the statistics pages, the points table, and the AI assistant.
"""
from django.db.models import Q

from core.models import Match, Player, Team


def dashboard_summary():
    total_matches = Match.objects.count()
    completed = Match.objects.filter(status=Match.Status.COMPLETED).count()
    upcoming = Match.objects.filter(status=Match.Status.UPCOMING).count()

    top_scorer = Player.objects.order_by('-runs').first()
    top_wicket_taker = Player.objects.order_by('-wickets').first()
    best_strike_rate = Player.objects.filter(runs__gt=0).order_by('-strike_rate').first()
    best_economy = Player.objects.filter(wickets__gt=0).order_by('economy_rate').first()
    points_leader = Team.objects.order_by('-points', '-net_run_rate').first()

    return {
        'total_teams': Team.objects.count(),
        'total_players': Player.objects.count(),
        'total_matches': total_matches,
        'completed_matches': completed,
        'upcoming_matches': upcoming,
        'top_scorer': top_scorer,
        'top_wicket_taker': top_wicket_taker,
        'best_strike_rate': best_strike_rate,
        'best_economy': best_economy,
        'points_leader': points_leader,
    }


def top_run_scorers(limit=10):
    return Player.objects.order_by('-runs')[:limit]


def top_wicket_takers(limit=10):
    return Player.objects.order_by('-wickets')[:limit]


def highest_averages(limit=10):
    return Player.objects.filter(runs__gt=0).order_by('-batting_average')[:limit]


def highest_strike_rates(limit=10):
    return Player.objects.filter(runs__gt=0).order_by('-strike_rate')[:limit]


def most_sixes(limit=10):
    return Player.objects.order_by('-sixes')[:limit]


def most_fours(limit=10):
    return Player.objects.order_by('-fours')[:limit]


def best_economy_rates(limit=10):
    return Player.objects.filter(wickets__gt=0).order_by('economy_rate')[:limit]


def best_bowling_averages(limit=10):
    return Player.objects.filter(wickets__gt=0).order_by('bowling_average')[:limit]


def most_maidens(limit=10):
    return Player.objects.order_by('-maidens')[:limit]


def team_standings():
    return Team.objects.all().order_by('-points', '-net_run_rate', 'name')


def batting_statistics(limit=10):
    return {
        'most_runs': list(top_run_scorers(limit)),
        'highest_average': list(highest_averages(limit)),
        'highest_strike_rate': list(highest_strike_rates(limit)),
        'most_sixes': list(most_sixes(limit)),
        'most_fours': list(most_fours(limit)),
    }


def bowling_statistics(limit=10):
    return {
        'most_wickets': list(top_wicket_takers(limit)),
        'best_economy': list(best_economy_rates(limit)),
        'best_average': list(best_bowling_averages(limit)),
        'most_maidens': list(most_maidens(limit)),
    }


def best_all_rounders(limit=10):
    return (
        Player.objects.filter(role=Player.Role.ALL_ROUNDER)
        .filter(Q(runs__gt=0) | Q(wickets__gt=0))
        .order_by('-runs', '-wickets')[:limit]
    )
