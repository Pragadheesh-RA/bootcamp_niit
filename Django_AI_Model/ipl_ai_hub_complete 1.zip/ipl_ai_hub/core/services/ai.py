"""
AI Cricket Assistant service.

This module is intentionally decoupled from Django views/templates so the
same service can be called from the REST API, the chat page, management
commands, or tests. The architecture is:

    Frontend -> Django API (api_views.AIAskAPIView)
             -> AI Service (this module, CricketAIService.ask)
                 -> Intent Detection (detect_intent)
                 -> Database Query (core.services.statistics / search)
                 -> Response Generator (persona/level aware)
             -> Frontend

`CricketAIService` ships with a fully local, rule-based implementation so
the project works with zero external dependencies and no API key. If
`settings.AI_API_KEY` is configured, a subclass or future extension point
can route through an external LLM instead -- the public `ask()` contract
does not need to change.

`ask()` is written defensively: any unexpected error while looking up data
is caught and turned into a normal (if apologetic) answer rather than an
exception, so a bug in one intent handler can never take down the whole
chat endpoint.
"""
import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from django.db.models import Q

from core.models import Match, Player, Team
from core.services import search as search_service
from core.services import statistics as stats_service

logger = logging.getLogger('core')


class Intent:
    TOP_RUNS = 'TOP_RUNS'
    TOP_WICKETS = 'TOP_WICKETS'
    TEAM_STANDINGS = 'TEAM_STANDINGS'
    TEAM_INFO = 'TEAM_INFO'
    PLAYER_INFO = 'PLAYER_INFO'
    MATCH_INFO = 'MATCH_INFO'
    TEAM_COMPARISON = 'TEAM_COMPARISON'
    PLAYER_COMPARISON = 'PLAYER_COMPARISON'
    STATISTICS = 'STATISTICS'
    ARTICLE_SEARCH = 'ARTICLE_SEARCH'
    GENERAL_CRICKET = 'GENERAL_CRICKET'
    UNKNOWN = 'UNKNOWN'


PERSONA_STYLES = {
    'CASUAL_FAN': {'greeting': 'Hey there!'},
    'BEGINNER': {'greeting': 'Great question!'},
    'STUDENT': {'greeting': "Let's break this down."},
    'CRICKET_ANALYST': {'greeting': 'Here is the read:'},
    'DATA_ANALYST': {'greeting': 'Pulling the numbers:'},
    'COACH': {'greeting': 'From a team-strategy angle:'},
    'RESEARCHER': {'greeting': 'For the record:'},
}

LEVEL_EXPLANATIONS = {
    'nrr': {
        'BEGINNER': (
            'Net Run Rate (NRR) is basically how much faster a team scores '
            'compared to how fast it lets the other team score. Higher is better.'
        ),
        'INTERMEDIATE': (
            'NRR = (runs scored / overs faced) - (runs conceded / overs bowled), '
            'calculated across all of a team’s matches. It rewards big, fast wins.'
        ),
        'ADVANCED': (
            'NRR aggregates run-rate differential across the whole season rather than '
            'per match: sum(runs scored) / sum(overs faced) minus sum(runs conceded) / '
            'sum(overs bowled). When two or more teams are level on points, the team with '
            'the higher NRR is ranked above the others, so blowout wins and tight losses '
            'both move the number more than close wins do.'
        ),
        'EXPERT': (
            'NRR is a season-aggregated differential, not an average of per-match rates, '
            'which is why it is not simply additive across games with different lengths '
            '(rain-affected/DLS matches use the revised overs and target). Mathematically, '
            'for a team T: NRR(T) = [sum(runs_for) / sum(overs_faced)] minus '
            '[sum(runs_against) / sum(overs_bowled)]. Because a single result can only '
            'shift the season total by a bounded amount, teams chasing NRR target both '
            'margin of victory and overs used, not just a win.'
        ),
    },
    'points_table': {
        'BEGINNER': (
            'The points table ranks teams by how many points they have won. A win is '
            'usually 2 points. Whoever is on top is doing the best this season.'
        ),
        'INTERMEDIATE': (
            'Teams earn 2 points per win, 0 for a loss, and 1 each for a no-result. '
            'Teams are ranked by total points first, and Net Run Rate breaks ties.'
        ),
        'ADVANCED': (
            'The table sorts teams by points, then by NRR as the primary tiebreaker. '
            'The top four at the end of the league stage usually advance to the playoffs.'
        ),
        'EXPERT': (
            'Ranking key is (points DESC, NRR DESC[, head-to-head DESC] depending on the '
            'season’s tournament regulations). Because points are coarse, NRR frequently '
            'decides the 4th playoff spot, which is why the run-rate mathematics above '
            'matters in practice, not just in theory.'
        ),
    },
}

SUGGESTED_QUESTIONS = [
    'Who has scored the most runs?',
    'Who is the highest wicket taker?',
    'Which team is currently leading?',
    'Compare CSK and RCB.',
    'Show me the next match.',
    'Who has the best strike rate?',
]

WELCOME_MESSAGE = (
    "\U0001F44B Welcome to IPL AI Hub!\n\n"
    "I'm your AI Cricket Assistant.\n"
    "What would you like to explore today?"
)


@dataclass
class AIResponse:
    intent: str
    entities: dict = field(default_factory=dict)
    answer: str = ''
    data: dict = field(default_factory=dict)
    source: str = 'database'
    success: bool = True

    def as_dict(self):
        return {
            'success': self.success,
            'intent': self.intent,
            'entities': self.entities,
            'answer': self.answer,
            'data': self.data,
            'source': self.source,
        }


def _find_teams(text):
    """Return Team objects whose name/short_name/city appear in the text."""
    text_lower = text.lower()
    matches = []
    for team in Team.objects.all():
        candidates = [team.name.lower(), team.short_name.lower(), team.city.lower()]
        if any(c in text_lower for c in candidates if c):
            matches.append(team)
    return matches


def _find_players(text):
    """Return Player objects whose name (or its last word) appears in the text."""
    text_lower = text.lower()
    text_words = text_lower.split()
    matches = []
    for player in Player.objects.select_related('team').all():
        name_lower = player.name.lower()
        name_parts = name_lower.split()
        if name_lower in text_lower or (name_parts and name_parts[-1] in text_words):
            matches.append(player)
    return matches


class CricketAIService:
    """Local, rule-based cricket assistant. No external API key required."""

    def welcome_message(self):
        return WELCOME_MESSAGE

    def suggested_questions(self):
        return list(SUGGESTED_QUESTIONS)

    # -- Public entry point -------------------------------------------------
    def ask(self, question: str, persona: Optional[str] = None, level: Optional[str] = None) -> dict:
        question = (question or '').strip()
        persona = (persona or 'CASUAL_FAN').upper()
        level = (level or 'BEGINNER').upper()

        if not question:
            return AIResponse(
                intent=Intent.UNKNOWN,
                answer="I didn't catch a question there. Try asking me something like "
                       "'Who has scored the most runs?'",
                success=False,
            ).as_dict()

        try:
            intent, entities = self.detect_intent(question)
            answer, data = self._route(intent, entities, question)
            answer = self._apply_persona_and_level(answer, persona, level, intent)
            return AIResponse(
                intent=intent, entities=entities, answer=answer, data=data, source='database'
            ).as_dict()
        except Exception:  # noqa: BLE001 -- last-resort safety net for the chat endpoint
            logger.exception('CricketAIService.ask failed for question=%r', question)
            return AIResponse(
                intent=Intent.UNKNOWN,
                answer="Sorry, I ran into a problem answering that. Please try rephrasing "
                       "your question, or ask about a specific player, team, or match.",
                success=False,
            ).as_dict()

    # -- Intent detection -----------------------------------------------------
    def detect_intent(self, question: str):
        text = question.lower()
        entities = {}

        teams = _find_teams(question)
        players = _find_players(question)

        is_comparison = bool(re.search(r'\bcompare\b|\bvs\.?\b| versus ', text))

        if is_comparison and len(teams) >= 2:
            entities['teams'] = [t.short_name for t in teams[:2]]
            return Intent.TEAM_COMPARISON, entities

        if is_comparison and len(players) >= 2:
            entities['players'] = [p.name for p in players[:2]]
            return Intent.PLAYER_COMPARISON, entities

        if re.search(r'most runs|top run|highest run|leading run|run scorer', text):
            return Intent.TOP_RUNS, entities

        if re.search(r'most wickets|top wicket|highest wicket|wicket taker', text):
            return Intent.TOP_WICKETS, entities

        if re.search(r'strike rate|economy|bowling average|batting average|maiden|best bowling', text) \
                and 'compare' not in text:
            return Intent.STATISTICS, entities

        if re.search(r'points table|standings|who.*leading|leader ?board', text):
            return Intent.TEAM_STANDINGS, entities

        if re.search(r'article|content|news about|read about|blog', text):
            entities['query'] = self._extract_topic(text)
            return Intent.ARTICLE_SEARCH, entities

        if re.search(r'next match|upcoming match|when.*play|match (result|info|details)|score', text):
            if teams:
                entities['teams'] = [t.short_name for t in teams[:1]]
            return Intent.MATCH_INFO, entities

        if teams and not players:
            entities['teams'] = [t.short_name for t in teams[:1]]
            return Intent.TEAM_INFO, entities

        if players:
            entities['players'] = [p.name for p in players[:1]]
            return Intent.PLAYER_INFO, entities

        if re.search(r'nrr|net run rate|points table|explain', text):
            return Intent.GENERAL_CRICKET, entities

        return Intent.UNKNOWN, entities

    def _extract_topic(self, text):
        for marker in ('about', 'on'):
            if marker in text:
                return text.split(marker, 1)[1].strip(' ?.!')
        return text.strip(' ?.!')

    # -- Routing ---------------------------------------------------------------
    def _route(self, intent, entities, question):
        handler = {
            Intent.TOP_RUNS: self._handle_top_runs,
            Intent.TOP_WICKETS: self._handle_top_wickets,
            Intent.TEAM_STANDINGS: self._handle_team_standings,
            Intent.TEAM_INFO: self._handle_team_info,
            Intent.PLAYER_INFO: self._handle_player_info,
            Intent.MATCH_INFO: self._handle_match_info,
            Intent.TEAM_COMPARISON: self._handle_team_comparison,
            Intent.PLAYER_COMPARISON: self._handle_player_comparison,
            Intent.STATISTICS: self._handle_statistics,
            Intent.ARTICLE_SEARCH: self._handle_article_search,
            Intent.GENERAL_CRICKET: self._handle_general_cricket,
        }.get(intent, self._handle_unknown)
        return handler(entities, question)

    def _handle_top_runs(self, entities, question):
        players = list(stats_service.top_run_scorers(5))
        if not players:
            return "There's no player data loaded yet. Run `py manage.py seed_data` first.", {}
        leader = players[0]
        answer = f'{leader.name} ({leader.team.short_name}) leads with {leader.runs} runs this season.'
        data = {'top_scorers': [
            {'name': p.name, 'team': p.team.short_name, 'runs': p.runs} for p in players
        ]}
        return answer, data

    def _handle_top_wickets(self, entities, question):
        players = list(stats_service.top_wicket_takers(5))
        if not players:
            return "There's no player data loaded yet. Run `py manage.py seed_data` first.", {}
        leader = players[0]
        answer = f'{leader.name} ({leader.team.short_name}) leads the wicket charts with {leader.wickets} wickets.'
        data = {'top_wicket_takers': [
            {'name': p.name, 'team': p.team.short_name, 'wickets': p.wickets} for p in players
        ]}
        return answer, data

    def _handle_team_standings(self, entities, question):
        teams = list(stats_service.team_standings())
        if not teams:
            return "There's no team data loaded yet. Run `py manage.py seed_data` first.", {}
        leader = teams[0]
        answer = (
            f'{leader.name} are currently top of the points table with {leader.points} points '
            f'and an NRR of {leader.net_run_rate}.'
        )
        data = {'standings': [
            {
                'position': i + 1,
                'team': t.name,
                'points': t.points,
                'nrr': str(t.net_run_rate),
                'wins': t.wins,
                'losses': t.losses,
            }
            for i, t in enumerate(teams)
        ]}
        return answer, data

    def _handle_team_info(self, entities, question):
        short_name = (entities.get('teams') or [None])[0]
        team = Team.objects.filter(short_name=short_name).first() if short_name else None
        if not team:
            return "I couldn't find that team. Try one of the official IPL team names.", {}
        answer = (
            f'{team.name} ({team.city}): {team.wins}W-{team.losses}L from '
            f'{team.matches_played} matches, {team.points} points, NRR {team.net_run_rate}.'
        )
        data = {
            'team': team.name,
            'city': team.city,
            'points': team.points,
            'wins': team.wins,
            'losses': team.losses,
            'nrr': str(team.net_run_rate),
        }
        return answer, data

    def _handle_player_info(self, entities, question):
        name = (entities.get('players') or [None])[0]
        player = Player.objects.filter(name=name).select_related('team').first() if name else None
        if not player:
            return "I couldn't find that player in the database yet.", {}
        answer = (
            f'{player.name} ({player.team.short_name}, {player.get_role_display()}): '
            f'{player.runs} runs, {player.wickets} wickets across {player.matches_played} matches. '
            f'Strike rate {player.strike_rate}, economy {player.economy_rate}.'
        )
        data = {
            'name': player.name,
            'team': player.team.short_name,
            'role': player.get_role_display(),
            'runs': player.runs,
            'wickets': player.wickets,
            'strike_rate': str(player.strike_rate),
            'economy_rate': str(player.economy_rate),
        }
        return answer, data

    def _handle_match_info(self, entities, question):
        short_name = (entities.get('teams') or [None])[0]
        qs = Match.objects.filter(status=Match.Status.UPCOMING).select_related('home_team', 'away_team')
        if short_name:
            qs = qs.filter(Q(home_team__short_name=short_name) | Q(away_team__short_name=short_name))
        match = qs.order_by('date', 'time').first()
        if not match:
            match = Match.objects.select_related('home_team', 'away_team').order_by('-date', '-time').first()
        if not match:
            return "There are no matches loaded yet. Run `py manage.py seed_data` first.", {}
        answer = (
            f'{match.home_team.short_name} vs {match.away_team.short_name} '
            f'({match.get_status_display()}) on {match.date} at {match.venue}.'
        )
        if match.status == Match.Status.COMPLETED and match.winner:
            answer += f' Result: {match.winner.short_name} won. {match.result}'.strip()
        data = {
            'home_team': match.home_team.short_name,
            'away_team': match.away_team.short_name,
            'date': str(match.date),
            'venue': match.venue,
            'status': match.status,
        }
        return answer, data

    def _handle_team_comparison(self, entities, question):
        names = entities.get('teams', [])
        teams = list(Team.objects.filter(short_name__in=names))
        if len(teams) < 2:
            return 'I need two valid team names to compare, e.g. "Compare CSK and RCB".', {}
        a, b = teams[0], teams[1]
        winner = a if (a.points, a.net_run_rate) >= (b.points, b.net_run_rate) else b
        answer = (
            f'{a.short_name}: {a.points} pts, {a.wins}W-{a.losses}L, NRR {a.net_run_rate}. '
            f'{b.short_name}: {b.points} pts, {b.wins}W-{b.losses}L, NRR {b.net_run_rate}. '
            f'{winner.short_name} currently has the edge.'
        )
        data = {
            'teams': [
                {'team': a.short_name, 'points': a.points, 'wins': a.wins, 'losses': a.losses, 'nrr': str(a.net_run_rate)},
                {'team': b.short_name, 'points': b.points, 'wins': b.wins, 'losses': b.losses, 'nrr': str(b.net_run_rate)},
            ]
        }
        return answer, data

    def _handle_player_comparison(self, entities, question):
        names = entities.get('players', [])
        players = list(Player.objects.filter(name__in=names).select_related('team'))
        if len(players) < 2:
            return 'I need two valid player names to compare, e.g. "Compare Kohli and Rohit Sharma".', {}
        a, b = players[0], players[1]
        answer = (
            f'{a.name}: {a.runs} runs, {a.wickets} wickets, SR {a.strike_rate}. '
            f'{b.name}: {b.runs} runs, {b.wickets} wickets, SR {b.strike_rate}.'
        )
        data = {
            'players': [
                {'name': a.name, 'runs': a.runs, 'wickets': a.wickets, 'strike_rate': str(a.strike_rate)},
                {'name': b.name, 'runs': b.runs, 'wickets': b.wickets, 'strike_rate': str(b.strike_rate)},
            ]
        }
        return answer, data

    def _handle_statistics(self, entities, question):
        text = question.lower()
        if 'economy' in text:
            players = list(stats_service.best_economy_rates(5))
            label = 'best economy rate'
            values = [f'{p.name} ({p.economy_rate})' for p in players]
        else:
            players = list(stats_service.highest_strike_rates(5))
            label = 'best strike rate'
            values = [f'{p.name} ({p.strike_rate})' for p in players]
        if not players:
            return "There's no statistical data loaded yet. Run `py manage.py seed_data` first.", {}
        answer = f'Players with the {label}: ' + ', '.join(values) + '.'
        data = {'label': label, 'players': values}
        return answer, data

    def _handle_article_search(self, entities, question):
        query = entities.get('query', '')
        articles = list(search_service.search_articles(query, limit=5))
        if not articles:
            return f"I couldn't find any articles about '{query}'.", {'articles': []}
        answer = f"Here's what I found about '{query}': " + '; '.join(a.title for a in articles)
        data = {'articles': [{'title': a.title, 'slug': a.slug, 'summary': a.summary} for a in articles]}
        return answer, data

    def _handle_general_cricket(self, entities, question):
        text = question.lower()
        if 'nrr' in text or 'net run rate' in text:
            return LEVEL_EXPLANATIONS['nrr']['INTERMEDIATE'], {'topic': 'nrr'}
        if 'points table' in text or 'standings' in text:
            return LEVEL_EXPLANATIONS['points_table']['INTERMEDIATE'], {'topic': 'points_table'}
        return (
            "I can help with IPL teams, players, matches, standings, and stats. "
            "Try asking something like 'Who has the most runs?'"
        ), {}

    def _handle_unknown(self, entities, question):
        return (
            "I'm not sure I understood that. Try one of the suggested questions, "
            "or ask about a specific player, team, or match."
        ), {}

    # -- Persona / level adaptation --------------------------------------------
    def _apply_persona_and_level(self, answer, persona, level, intent):
        style = PERSONA_STYLES.get(persona, PERSONA_STYLES['CASUAL_FAN'])

        # Swap in a level-specific explanation for general cricket topics.
        if intent == Intent.GENERAL_CRICKET:
            for levels in LEVEL_EXPLANATIONS.values():
                if answer in levels.values():
                    answer = levels.get(level, levels['INTERMEDIATE'])
                    break

        return f"{style['greeting']} {answer}"


def get_ai_service() -> CricketAIService:
    return CricketAIService()
