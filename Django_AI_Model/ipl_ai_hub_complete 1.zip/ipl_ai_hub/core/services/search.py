"""
Global search service.

Provides a single entry point that fans a query out across teams,
players, matches, and articles.
"""
from django.db.models import Q

from core.models import Article, Match, Player, Team


def search_teams(query, limit=10):
    if not query:
        return Team.objects.none()
    return Team.objects.filter(
        Q(name__icontains=query) | Q(short_name__icontains=query) | Q(city__icontains=query)
    )[:limit]


def search_players(query, limit=10):
    if not query:
        return Player.objects.none()
    return Player.objects.filter(
        Q(name__icontains=query)
        | Q(team__name__icontains=query)
        | Q(team__short_name__icontains=query)
    ).select_related('team')[:limit]


def search_matches(query, limit=10):
    if not query:
        return Match.objects.none()
    return Match.objects.filter(
        Q(home_team__name__icontains=query)
        | Q(away_team__name__icontains=query)
        | Q(venue__icontains=query)
    ).select_related('home_team', 'away_team')[:limit]


def search_articles(query, limit=10, category=None, tag=None):
    qs = Article.objects.all()
    if query:
        qs = qs.filter(
            Q(title__icontains=query)
            | Q(summary__icontains=query)
            | Q(content__icontains=query)
            | Q(tags__name__icontains=query)
        ).distinct()
    if category:
        qs = qs.filter(category__iexact=category)
    if tag:
        qs = qs.filter(tags__name__icontains=tag).distinct()
    return qs[:limit]


def global_search(query, limit=10):
    query = (query or '').strip()
    return {
        'query': query,
        'teams': list(search_teams(query, limit)),
        'players': list(search_players(query, limit)),
        'matches': list(search_matches(query, limit)),
        'articles': list(search_articles(query, limit)),
    }


def related_articles(article, limit=4):
    qs = Article.objects.exclude(pk=article.pk)
    if article.tags.exists():
        qs = qs.filter(tags__in=article.tags.all()).distinct()
    else:
        qs = qs.filter(category=article.category)
    return qs[:limit]
