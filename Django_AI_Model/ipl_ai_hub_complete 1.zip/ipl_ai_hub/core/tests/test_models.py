import datetime

import pytest
from django.db import IntegrityError, transaction

from core.models import Article, Match, Player, Team


@pytest.mark.django_db
class TestTeamModel:
    def test_team_creation(self, team_csk):
        assert team_csk.pk is not None
        assert str(team_csk) == 'Chennai Super Kings'

    def test_team_short_name_unique(self, team_csk):
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                Team.objects.create(name='Another CSK', short_name='CSK', city='Chennai')

    def test_team_default_ordering_by_points(self, team_csk, team_rcb):
        teams = list(Team.objects.all())
        assert teams[0] == team_csk


@pytest.mark.django_db
class TestPlayerModel:
    def test_player_creation(self, player_kohli):
        assert player_kohli.pk is not None
        assert player_kohli.team.short_name == 'RCB'

    def test_player_str_includes_team(self, player_kohli):
        assert 'RCB' in str(player_kohli)

    def test_player_requires_team(self):
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                Player.objects.create(name='No Team Player', team_id=999999)


@pytest.mark.django_db
class TestMatchModel:
    def test_match_creation(self, match_upcoming):
        assert match_upcoming.pk is not None
        assert match_upcoming.status == Match.Status.UPCOMING

    def test_match_number_unique(self, match_upcoming, team_csk, team_rcb):
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                Match.objects.create(
                    match_number=match_upcoming.match_number,
                    home_team=team_rcb, away_team=team_csk,
                    date=datetime.date.today(), time=datetime.time(19, 30),
                    venue='Some Stadium',
                )

    def test_home_and_away_team_must_differ(self, team_csk):
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                Match.objects.create(
                    match_number=99, home_team=team_csk, away_team=team_csk,
                    date=datetime.date.today(), time=datetime.time(19, 30),
                    venue='Some Stadium',
                )


@pytest.mark.django_db
class TestArticleModel:
    def test_article_creation_generates_slug(self, article_kohli):
        assert article_kohli.slug == 'virat-kohli-reaches-yet-another-milestone'

    def test_article_tags_relationship(self, article_kohli):
        assert article_kohli.tags.filter(name='Virat Kohli').exists()

    def test_duplicate_title_gets_unique_slug(self, article_kohli):
        second = Article.objects.create(
            title=article_kohli.title,
            summary='Different summary',
            content='Different content',
            category=Article.Category.NEWS,
            published_date=article_kohli.published_date,
        )
        assert second.slug != article_kohli.slug
        assert second.slug.startswith(article_kohli.slug)
