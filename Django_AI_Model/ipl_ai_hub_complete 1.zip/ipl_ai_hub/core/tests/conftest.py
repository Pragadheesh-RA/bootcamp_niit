import datetime
from decimal import Decimal

import pytest

from core.models import Article, Match, Player, Tag, Team


@pytest.fixture
def team_csk(db):
    return Team.objects.create(
        name='Chennai Super Kings', short_name='CSK', city='Chennai',
        matches_played=10, wins=7, losses=3, points=14, net_run_rate=Decimal('0.650'),
    )


@pytest.fixture
def team_rcb(db):
    return Team.objects.create(
        name='Royal Challengers Bengaluru', short_name='RCB', city='Bengaluru',
        matches_played=10, wins=5, losses=5, points=10, net_run_rate=Decimal('0.100'),
    )


@pytest.fixture
def player_kohli(db, team_rcb):
    return Player.objects.create(
        name='Virat Kohli', team=team_rcb, role=Player.Role.BATTER,
        runs=460, wickets=0, strike_rate=Decimal('146.80'), matches_played=10,
    )


@pytest.fixture
def player_dhoni(db, team_csk):
    return Player.objects.create(
        name='MS Dhoni', team=team_csk, role=Player.Role.WICKETKEEPER,
        runs=210, wickets=0, strike_rate=Decimal('158.20'), matches_played=9,
    )


@pytest.fixture
def player_bumrah(db, team_csk):
    return Player.objects.create(
        name='Jasprit Bumrah', team=team_csk, role=Player.Role.BOWLER,
        runs=10, wickets=18, economy_rate=Decimal('6.40'), matches_played=10,
    )


@pytest.fixture
def match_upcoming(db, team_csk, team_rcb):
    return Match.objects.create(
        match_number=1, home_team=team_csk, away_team=team_rcb,
        date=datetime.date.today() + datetime.timedelta(days=3),
        time=datetime.time(19, 30), venue='MA Chidambaram Stadium, Chennai',
        status=Match.Status.UPCOMING,
    )


@pytest.fixture
def article_kohli(db):
    article = Article.objects.create(
        title='Virat Kohli Reaches Yet Another Milestone',
        summary='Kohli keeps setting new standards.',
        content='Full article body about Virat Kohli and RCB.',
        category=Article.Category.PLAYERS,
        published_date=datetime.datetime.now(datetime.timezone.utc),
    )
    tag, _ = Tag.objects.get_or_create(name='Virat Kohli')
    article.tags.add(tag)
    return article
