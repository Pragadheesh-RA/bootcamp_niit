import pytest

from core.services.ai import CricketAIService, Intent


@pytest.fixture
def ai_service():
    return CricketAIService()


@pytest.mark.django_db
class TestIntentDetection:
    def test_top_runs_intent(self, ai_service, player_kohli):
        result = ai_service.ask('Who has scored the most runs?')
        assert result['intent'] == Intent.TOP_RUNS
        assert result['success'] is True

    def test_top_wickets_intent(self, ai_service, player_bumrah):
        result = ai_service.ask('Who is the highest wicket taker?')
        assert result['intent'] == Intent.TOP_WICKETS

    def test_team_standings_intent(self, ai_service, team_csk, team_rcb):
        result = ai_service.ask('Which team is currently leading?')
        assert result['intent'] == Intent.TEAM_STANDINGS
        assert 'Chennai Super Kings' in result['answer']

    def test_player_info_intent(self, ai_service, player_kohli):
        result = ai_service.ask('Give me information about Virat Kohli.')
        assert result['intent'] == Intent.PLAYER_INFO
        assert 'Kohli' in result['answer']

    def test_team_comparison_intent(self, ai_service, team_csk, team_rcb):
        result = ai_service.ask('Compare CSK and RCB.')
        assert result['intent'] == Intent.TEAM_COMPARISON
        assert 'CSK' in result['answer'] and 'RCB' in result['answer']

    def test_player_comparison_intent(self, ai_service, player_kohli, player_dhoni):
        result = ai_service.ask('Compare Virat Kohli and MS Dhoni.')
        assert result['intent'] == Intent.PLAYER_COMPARISON

    def test_unknown_intent_for_gibberish(self, ai_service):
        result = ai_service.ask('asdkfjhaskldjfh random words banana spaceship')
        assert result['intent'] == Intent.UNKNOWN

    def test_empty_question_handled_gracefully(self, ai_service):
        result = ai_service.ask('')
        assert result['success'] is False
        assert result['intent'] == Intent.UNKNOWN

    def test_persona_and_level_change_response_text(self, ai_service, player_kohli):
        casual = ai_service.ask('Who has scored the most runs?', persona='CASUAL_FAN')
        analyst = ai_service.ask('Who has scored the most runs?', persona='DATA_ANALYST')
        assert casual['answer'] != analyst['answer']

    def test_nrr_explanation_adapts_to_level(self, ai_service):
        beginner = ai_service.ask('Explain NRR in simple terms.', level='BEGINNER')
        advanced = ai_service.ask('Explain how NRR affects IPL qualification mathematically.', level='ADVANCED')
        assert beginner['answer'] != advanced['answer']
        assert beginner['intent'] == Intent.GENERAL_CRICKET

    def test_ask_never_raises_even_on_empty_database(self, ai_service):
        # No teams/players/matches seeded at all for this test -- every
        # handler must degrade gracefully instead of raising.
        for question in [
            'Who has scored the most runs?',
            'Who is the highest wicket taker?',
            'Which team is currently leading?',
            'Show me the next match.',
            'Explain NRR.',
        ]:
            result = ai_service.ask(question)
            assert isinstance(result, dict)
            assert 'answer' in result
