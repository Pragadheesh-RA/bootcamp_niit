import json

import pytest

from core.models import ChatSession, Team


@pytest.mark.django_db
class TestTeamAPI:
    def test_list_teams(self, client, team_csk, team_rcb):
        response = client.get('/api/teams/')
        assert response.status_code == 200
        data = response.json()
        results = data['results'] if 'results' in data else data
        assert len(results) == 2

    def test_create_team(self, client):
        payload = {'name': 'Delhi Capitals', 'short_name': 'DC', 'city': 'Delhi'}
        response = client.post('/api/teams/', data=json.dumps(payload), content_type='application/json')
        assert response.status_code == 201
        assert Team.objects.filter(short_name='DC').exists()

    def test_retrieve_team(self, client, team_csk):
        response = client.get(f'/api/teams/{team_csk.pk}/')
        assert response.status_code == 200
        assert response.json()['short_name'] == 'CSK'

    def test_retrieve_missing_team_returns_404(self, client):
        response = client.get('/api/teams/999999/')
        assert response.status_code == 404


@pytest.mark.django_db
class TestPlayerAPI:
    def test_list_players(self, client, player_kohli):
        response = client.get('/api/players/')
        assert response.status_code == 200

    def test_filter_players_by_team(self, client, player_kohli, player_dhoni):
        response = client.get('/api/players/', {'team': 'RCB'})
        data = response.json()
        results = data['results'] if 'results' in data else data
        names = [p['name'] for p in results]
        assert 'Virat Kohli' in names
        assert 'MS Dhoni' not in names

    def test_create_player_requires_team(self, client):
        response = client.post(
            '/api/players/',
            data=json.dumps({'name': 'No Team', 'role': 'BATTER'}),
            content_type='application/json',
        )
        assert response.status_code == 400


@pytest.mark.django_db
class TestMatchAPI:
    def test_list_matches(self, client, match_upcoming):
        response = client.get('/api/matches/')
        assert response.status_code == 200

    def test_reject_same_home_and_away_team(self, client, team_csk):
        payload = {
            'match_number': 55, 'home_team': team_csk.id, 'away_team': team_csk.id,
            'date': '2026-01-01', 'time': '19:30:00', 'venue': 'Some Stadium',
        }
        response = client.post('/api/matches/', data=json.dumps(payload), content_type='application/json')
        assert response.status_code == 400


@pytest.mark.django_db
class TestStandingsAPI:
    def test_standings_ordered_by_points(self, client, team_csk, team_rcb):
        response = client.get('/api/standings/')
        assert response.status_code == 200
        data = response.json()
        assert data['success'] is True
        assert data['standings'][0]['short_name'] == 'CSK'


@pytest.mark.django_db
class TestStatisticsAPI:
    def test_statistics_endpoint(self, client, player_kohli, player_bumrah):
        response = client.get('/api/statistics/')
        assert response.status_code == 200
        data = response.json()
        assert 'batting' in data and 'bowling' in data


@pytest.mark.django_db
class TestAIApi:
    def test_ai_ask_requires_question(self, client):
        response = client.post('/api/ai/ask/', data=json.dumps({}), content_type='application/json')
        assert response.status_code == 400

    def test_ai_ask_top_runs(self, client, player_kohli):
        response = client.post(
            '/api/ai/ask/',
            data=json.dumps({'question': 'Who has scored the most runs?'}),
            content_type='application/json',
        )
        assert response.status_code == 200
        data = response.json()
        assert data['success'] is True
        assert data['intent'] == 'TOP_RUNS'
        assert 'Kohli' in data['answer']

    def test_ai_ask_persists_chat_session(self, client, player_kohli):
        response = client.post(
            '/api/ai/ask/',
            data=json.dumps({'question': 'Who has scored the most runs?'}),
            content_type='application/json',
        )
        session_key = response.json()['session_key']
        assert ChatSession.objects.filter(session_key=session_key).exists()
        session = ChatSession.objects.get(session_key=session_key)
        assert session.messages.count() == 2

    def test_ai_ask_does_not_require_csrf_token(self, client, player_kohli):
        # Regression check: the chat widget calls this endpoint anonymously
        # without necessarily having a CSRF cookie set; it must not 403.
        response = client.post(
            '/api/ai/ask/',
            data=json.dumps({'question': 'Who is the highest wicket taker?'}),
            content_type='application/json',
        )
        assert response.status_code == 200
