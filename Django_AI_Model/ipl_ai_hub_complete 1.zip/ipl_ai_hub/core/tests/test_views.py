import pytest


@pytest.mark.django_db
class TestFrontendPages:
    def test_home_page_loads(self, client, team_csk):
        response = client.get('/')
        assert response.status_code == 200
        assert b'IPL AI Hub' in response.content

    def test_teams_page_loads(self, client, team_csk, team_rcb):
        response = client.get('/teams/')
        assert response.status_code == 200
        assert b'Chennai Super Kings' in response.content

    def test_team_detail_page_loads(self, client, team_csk):
        response = client.get(f'/teams/{team_csk.pk}/')
        assert response.status_code == 200

    def test_team_detail_404_for_missing_team(self, client):
        response = client.get('/teams/999999/')
        assert response.status_code == 404

    def test_players_page_loads(self, client, player_kohli):
        response = client.get('/players/')
        assert response.status_code == 200
        assert b'Virat Kohli' in response.content

    def test_players_page_filters_by_team(self, client, player_kohli, player_dhoni):
        response = client.get('/players/', {'team': 'RCB'})
        assert b'Virat Kohli' in response.content
        assert b'MS Dhoni' not in response.content

    def test_matches_page_loads(self, client, match_upcoming):
        response = client.get('/matches/')
        assert response.status_code == 200

    def test_standings_page_loads(self, client, team_csk):
        response = client.get('/standings/')
        assert response.status_code == 200

    def test_statistics_page_loads(self, client, player_kohli):
        response = client.get('/statistics/')
        assert response.status_code == 200

    def test_articles_page_loads(self, client, article_kohli):
        response = client.get('/articles/')
        assert response.status_code == 200
        assert b'Virat Kohli' in response.content

    def test_article_detail_page_loads(self, client, article_kohli):
        response = client.get(f'/articles/{article_kohli.slug}/')
        assert response.status_code == 200

    def test_ai_page_loads(self, client):
        response = client.get('/ai/')
        assert response.status_code == 200
        assert b'AI Cricket Assistant' in response.content

    def test_ai_page_sets_csrf_cookie(self, client):
        response = client.get('/ai/')
        assert 'csrftoken' in response.cookies

    def test_search_page_loads(self, client, player_kohli):
        response = client.get('/search/', {'q': 'Kohli'})
        assert response.status_code == 200
        assert b'Virat Kohli' in response.content
