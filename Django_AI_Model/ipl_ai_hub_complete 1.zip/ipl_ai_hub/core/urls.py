"""Frontend URL routing for the IPL AI Hub platform."""
from django.urls import path

from core import views

app_name = 'core'

urlpatterns = [
    path('', views.index, name='index'),
    path('teams/', views.team_list, name='team_list'),
    path('teams/<int:pk>/', views.team_detail, name='team_detail'),
    path('players/', views.player_list, name='player_list'),
    path('players/<int:pk>/', views.player_detail, name='player_detail'),
    path('matches/', views.match_list, name='match_list'),
    path('matches/<int:pk>/', views.match_detail, name='match_detail'),
    path('standings/', views.standings, name='standings'),
    path('statistics/', views.statistics, name='statistics'),
    path('articles/', views.article_list, name='article_list'),
    path('articles/<slug:slug>/', views.article_detail, name='article_detail'),
    path('ai/', views.ai_assistant, name='ai_assistant'),
    path('search/', views.search_view, name='search'),
]
