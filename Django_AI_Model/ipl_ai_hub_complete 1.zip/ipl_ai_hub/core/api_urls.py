"""REST API URL routing, mounted at /api/ by config.urls."""
from django.urls import include, path
from rest_framework.routers import DefaultRouter

from core import api_views

router = DefaultRouter()
router.register(r'teams', api_views.TeamViewSet, basename='team')
router.register(r'players', api_views.PlayerViewSet, basename='player')
router.register(r'matches', api_views.MatchViewSet, basename='match')
router.register(r'articles', api_views.ArticleViewSet, basename='article')

urlpatterns = [
    path('standings/', api_views.StandingsAPIView.as_view(), name='api_standings'),
    path('statistics/', api_views.StatisticsAPIView.as_view(), name='api_statistics'),
    path('search/', api_views.SearchAPIView.as_view(), name='api_search'),
    path('ai/ask/', api_views.AIAskAPIView.as_view(), name='api_ai_ask'),
    path('ai/welcome/', api_views.ai_welcome, name='api_ai_welcome'),
    path('', include(router.urls)),
]
