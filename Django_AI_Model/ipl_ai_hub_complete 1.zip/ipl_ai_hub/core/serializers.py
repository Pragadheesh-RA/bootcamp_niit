"""DRF serializers for the IPL AI Hub API."""
from rest_framework import serializers

from core.models import Article, ChatMessage, ChatSession, Match, Player, Tag, Team


class TeamSerializer(serializers.ModelSerializer):
    logo = serializers.ImageField(required=False, allow_null=True)

    class Meta:
        model = Team
        fields = [
            'id', 'name', 'short_name', 'city', 'logo', 'matches_played',
            'wins', 'losses', 'no_result', 'points', 'net_run_rate',
            'description', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class TeamSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = ['id', 'name', 'short_name', 'city']


class PlayerSerializer(serializers.ModelSerializer):
    team_detail = TeamSummarySerializer(source='team', read_only=True)
    role_display = serializers.CharField(source='get_role_display', read_only=True)

    class Meta:
        model = Player
        fields = [
            'id', 'name', 'team', 'team_detail', 'role', 'role_display', 'image',
            'runs', 'wickets', 'strike_rate', 'economy_rate', 'matches_played',
            'batting_average', 'bowling_average', 'sixes', 'fours',
            'highest_score', 'best_bowling', 'maidens', 'description',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_team(self, value):
        if value is None:
            raise serializers.ValidationError('A team is required.')
        return value


class MatchSerializer(serializers.ModelSerializer):
    home_team_detail = TeamSummarySerializer(source='home_team', read_only=True)
    away_team_detail = TeamSummarySerializer(source='away_team', read_only=True)
    winner_detail = TeamSummarySerializer(source='winner', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = Match
        fields = [
            'id', 'match_number', 'home_team', 'home_team_detail', 'away_team',
            'away_team_detail', 'date', 'time', 'venue', 'status', 'status_display',
            'score', 'winner', 'winner_detail', 'result', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        home = attrs.get('home_team', getattr(self.instance, 'home_team', None))
        away = attrs.get('away_team', getattr(self.instance, 'away_team', None))
        if home and away and home == away:
            raise serializers.ValidationError('home_team and away_team must be different.')
        return attrs


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name', 'slug']
        read_only_fields = ['id', 'slug']


class ArticleSerializer(serializers.ModelSerializer):
    tags = TagSerializer(many=True, read_only=True)
    tag_names = serializers.ListField(
        child=serializers.CharField(max_length=50), write_only=True, required=False
    )

    class Meta:
        model = Article
        fields = [
            'id', 'title', 'slug', 'summary', 'content', 'category', 'author',
            'image', 'published_date', 'source_url', 'tags', 'tag_names',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'slug', 'created_at', 'updated_at']

    def create(self, validated_data):
        tag_names = validated_data.pop('tag_names', [])
        article = Article.objects.create(**validated_data)
        self._set_tags(article, tag_names)
        return article

    def update(self, instance, validated_data):
        tag_names = validated_data.pop('tag_names', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        if tag_names is not None:
            self._set_tags(instance, tag_names)
        return instance

    def _set_tags(self, article, tag_names):
        if not tag_names:
            return
        tags = [Tag.objects.get_or_create(name=name.strip())[0] for name in tag_names if name.strip()]
        article.tags.set(tags)


class StandingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = [
            'id', 'name', 'short_name', 'matches_played', 'wins', 'losses',
            'no_result', 'points', 'net_run_rate',
        ]


class ChatMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChatMessage
        fields = ['id', 'role', 'message', 'intent', 'created_at']
        read_only_fields = fields


class ChatSessionSerializer(serializers.ModelSerializer):
    messages = ChatMessageSerializer(many=True, read_only=True)

    class Meta:
        model = ChatSession
        fields = ['id', 'session_key', 'persona', 'level', 'messages', 'created_at']
        read_only_fields = fields


class AIAskRequestSerializer(serializers.Serializer):
    question = serializers.CharField(max_length=1000, allow_blank=False)
    persona = serializers.CharField(max_length=30, required=False, allow_blank=True)
    level = serializers.CharField(max_length=30, required=False, allow_blank=True)
    session_key = serializers.CharField(max_length=64, required=False, allow_blank=True)

    def validate_question(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError('question cannot be empty.')
        return value
